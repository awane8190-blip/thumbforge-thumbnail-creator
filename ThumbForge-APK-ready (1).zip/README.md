# ThumbForge — Create Scroll-Stopping Thumbnails

A mobile-first thumbnail creator for YouTube, YouTube Shorts, TikTok and Instagram
creators. Choose a template, upload an image, add text and graphics, and export
your finished thumbnail — all in the browser.

## What's included

1. **Homepage** — hero, format cards (1280×720, 1080×1920 x2), features
2. **Template library** — categories, search, lazy-loaded previews, premium tags
3. **Thumbnail editor** — text/image/shape/sticker/emoji, layers, undo/redo, drag,
   rotate, resize, opacity, outline, shadow, backgrounds
4. **AI assistant** — headline, layout, visual, background and style suggestions
5. **Login / signup / profile** — demo auth stored in the browser
6. **Projects dashboard** — save, rename, duplicate, delete, reopen
7. **Pricing** — Free vs Premium plans with clear feature labels
8. **Responsive mobile layout** — bottom sheets, touch-friendly toolbars,
   dedicated 5-tab mobile nav
9. **Export** — PNG or JPG, exact target size, HD 2× (Premium), instant preview

## Tech stack

- React 19 + Vite 7 + TypeScript
- Tailwind CSS 4
- `react-router-dom` (HashRouter — works out-of-the-box on static hosts)
- `html-to-image` — client-side PNG/JPG export
- `lucide-react` — icons

Everything runs 100% in the browser. There is no backend requirement to try it.

## Development

```bash
npm install
npm run dev      # start dev server
npm run build    # production build → dist/
npm run preview  # preview the production build
```

## Optional integrations (setup instructions)

The MVP is fully self-contained. To productionize, wire the following services.
**Never commit API keys to the frontend** — always put them behind a backend
proxy or server function.

### 1. Real accounts & project storage

The current implementation stores users and projects in `localStorage`
(namespaced under `thumbforge.*`). Replace `src/context/AuthContext.tsx` and
`src/context/ProjectsContext.tsx` with a real backend such as:

- **Supabase** — `@supabase/supabase-js`, use Row Level Security so users can
  only read/write their own projects.
- **Firebase** — Auth + Firestore.
- **Custom API** — plug in `fetch` calls with an httpOnly cookie session.

Environment variables (example, Supabase):

```
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
```

Only the anon/public key belongs in the frontend. All privileged keys must stay
on the server.

### 2. Real AI assistant

`src/components/editor/AIAssistant.tsx` currently uses an offline heuristic
generator. To use a real LLM (OpenAI, Anthropic, Gemini, etc.):

1. Create a serverless function (e.g. Vercel/Netlify function or Supabase Edge
   Function) that accepts `{ topic }` and returns the structured suggestion.
2. Put the LLM API key on the server only (`OPENAI_API_KEY`, etc.).
3. Replace `generateFromTopic()` with a `fetch("/api/ai-thumbnail", ...)` call.

### 3. Payments (Premium plan)

The Pricing page contains a placeholder "Upgrade to Premium" button that
activates a local `premium` flag. Do **not** ship this to production without a
real payment provider. Recommended:

- **Stripe Checkout** — create a checkout session on your server, redirect the
  user, verify with a webhook, then flip the account's plan.
- **Paddle / LemonSqueezy** — merchant-of-record alternatives with similar
  webhook flows.

Never embed a Stripe **secret** key in the frontend; only the publishable key.

### 4. Advertisements

The `AdPlaceholder` component reserves space where ads could appear on the free
plan. Replace it with your ad-network snippet (Google AdSense, Ezoic, etc.) and
respect your provider's policies. The component automatically hides itself for
premium users.

## Security notes

- Uploaded files are validated by MIME type (PNG / JPG / WEBP / GIF) and size
  (max 8 MB). They are processed with `FileReader` and never leave the browser
  in the demo.
- Demo authentication is **not** secure — passwords are hashed with a trivial
  local hash for demo purposes only. Replace with a real auth provider before
  going to production.
- Projects are namespaced per user email in localStorage. Once you connect a
  real backend, enforce authorization server-side (row-level security or
  equivalent). Never rely on client-side checks alone.
- API keys must live on the server, not in `VITE_*` variables if they are
  secret. `VITE_*` variables are **inlined into the built JS** and are public.

## Performance

- Template previews use `IntersectionObserver` to lazy-mount only when scrolled
  into view.
- Canvas dragging uses pointer events with `touch-action: none` for smooth
  low-end Android performance.
- Animations are kept minimal (fade-in, small transforms) to keep the editor
  responsive.
- The final build is a single self-contained `dist/index.html` (vite-plugin-
  singlefile) that can be dropped on any static host.

## Not claimed

ThumbForge does not promise more views. A great cover helps, but content and
topic matter most.
