# ThumbForge — Android APK/AAB preparation

This project is prepared to be wrapped with Capacitor as an Android app.

## App identity
- App name: ThumbForge
- Package ID: `com.thumbforge.app`
- Web output: `dist/`

## Build commands

Run these in a Node.js environment:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Then in Android Studio:
- Build > Build APK(s) for a test APK.
- Build > Generate Signed Bundle / APK > Android App Bundle for Google Play.

For later web-code updates:

```bash
npm run build
npx cap sync android
```

## Mobile-only note
The source project itself is now APK-ready, but generating a signed Android APK/AAB still requires an Android build environment. A cloud build service can provide that environment if no computer is available.

## Important production notes
- `localStorage` auth/projects are demo-only and should be replaced with a real backend before treating accounts as secure.
- The AI assistant is currently an offline suggestion generator; a real AI API needs a server-side API key.
- Premium/payment controls are placeholders and are not real billing.
