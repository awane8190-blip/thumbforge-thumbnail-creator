import { useEffect, useRef, useState } from "react";
import { toPng, toJpeg } from "html-to-image";
import { CanvasRender } from "../CanvasRender";
import type { CanvasBackground, CanvasElement } from "../../types";
import { Download, X, Sparkles } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

interface Props {
  width: number;
  height: number;
  background: CanvasBackground;
  elements: CanvasElement[];
  filename: string;
  onClose: () => void;
}

export function ExportModal({ width, height, background, elements, filename, onClose }: Props) {
  const previewRef = useRef<HTMLDivElement | null>(null);
  const exportRef = useRef<HTMLDivElement | null>(null);
  const [format, setFormat] = useState<"png" | "jpg">("png");
  const [quality, setQuality] = useState<"standard" | "hd">("standard");
  const [busy, setBusy] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    // Trap scrolling behind
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, []);

  const exportImage = async () => {
    if (!exportRef.current) return;
    setBusy(true);
    try {
      const scale = quality === "hd" ? 2 : 1;
      const opts = {
        pixelRatio: scale,
        cacheBust: true,
        backgroundColor: undefined,
        width, // render at exact target size
        height,
      };
      const dataUrl = format === "png"
        ? await toPng(exportRef.current, opts)
        : await toJpeg(exportRef.current, { ...opts, quality: 0.95, backgroundColor: "#000" });
      const a = document.createElement("a");
      a.href = dataUrl;
      a.download = `${filename || "thumbnail"}.${format}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (e) {
      console.error(e);
      alert("Export failed. Try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-2 sm:p-4">
      <div className="w-full max-w-2xl bg-[#12121b] border border-[#1e1e2b] rounded-2xl overflow-hidden animate-[fadeInUp_.25s_ease]">
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#1e1e2b]">
          <div className="font-bold">Export thumbnail</div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-[#1a1a26]" aria-label="Close">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto">
          <div ref={previewRef} className="flex items-center justify-center bg-black/40 rounded-xl p-3" style={{ minHeight: 200 }}>
            <div className="max-w-full" style={{ maxHeight: "40vh" }}>
              <CanvasRender
                width={width}
                height={height}
                background={background}
                elements={elements}
                fixedRenderWidth={Math.min(560, window.innerWidth - 60)}
              />
            </div>
          </div>

          {/* Hidden full-size export container */}
          <div
            style={{
              position: "fixed",
              left: -99999,
              top: 0,
              pointerEvents: "none",
              width,
              height,
            }}
          >
            <div ref={exportRef} style={{ width, height }}>
              <CanvasRender
                width={width}
                height={height}
                background={background}
                elements={elements}
                fixedRenderWidth={width}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="text-xs text-neutral-400 mb-1.5">Format</div>
              <div className="grid grid-cols-2 gap-2">
                {(["png", "jpg"] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setFormat(f)}
                    className={`px-3 py-2.5 rounded-lg text-sm font-semibold border ${
                      format === f ? "bg-white text-black border-white" : "bg-[#0f0f18] border-[#262633] text-neutral-300"
                    }`}
                  >
                    {f.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-xs text-neutral-400 mb-1.5">Quality</div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setQuality("standard")}
                  className={`px-3 py-2.5 rounded-lg text-sm font-semibold border ${
                    quality === "standard" ? "bg-white text-black border-white" : "bg-[#0f0f18] border-[#262633] text-neutral-300"
                  }`}
                >
                  Standard
                </button>
                <button
                  onClick={() => {
                    if (user?.plan !== "premium") {
                      alert("HD export is a Premium feature. Upgrade in Pricing to unlock 2× export.");
                      return;
                    }
                    setQuality("hd");
                  }}
                  className={`px-3 py-2.5 rounded-lg text-sm font-semibold border relative ${
                    quality === "hd" ? "bg-white text-black border-white" : "bg-[#0f0f18] border-[#262633] text-neutral-300"
                  }`}
                >
                  HD 2×
                  <Sparkles className="w-3 h-3 text-amber-400 absolute -top-1 -right-1" />
                </button>
              </div>
            </div>
          </div>

          <div className="text-xs text-neutral-500">
            Export dimensions: <b>{width} × {height}</b>{quality === "hd" && <> (rendered @ 2×)</>}
          </div>
        </div>

        <div className="p-4 border-t border-[#1e1e2b] flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 sm:flex-none bg-[#1a1a26] hover:bg-[#22222f] px-4 py-3 rounded-xl font-semibold"
          >
            Cancel
          </button>
          <button
            onClick={exportImage}
            disabled={busy}
            className="flex-1 inline-flex items-center justify-center gap-2 brand-bg text-white px-4 py-3 rounded-xl font-semibold btn-glow disabled:opacity-60"
          >
            <Download className="w-4 h-4" />
            {busy ? "Preparing..." : "Download"}
          </button>
        </div>
      </div>
    </div>
  );
}
