import { useState } from "react";
import { Sparkles, Wand2, Loader2 } from "lucide-react";

interface Suggestion {
  headlines: string[];
  layout: string;
  visualElements: string[];
  background: string;
  textPlacement: string;
  style: string;
}

/**
 * NOTE: This is a client-side heuristic generator. It is intentionally offline.
 * To upgrade to a real LLM (OpenAI, Anthropic, etc.), send `topic` to a backend
 * endpoint that holds the API key — never expose the key in the frontend.
 */
function generateFromTopic(topic: string): Suggestion {
  const clean = topic.trim().replace(/\s+/g, " ");
  const upper = clean.toUpperCase();
  const words = clean.split(" ").filter(Boolean);
  const key = words.slice(0, 3).join(" ").toUpperCase();

  const isGaming = /game|gaming|win|lose|fortnite|minecraft|clip/i.test(clean);
  const isFood = /food|recipe|cook|bake|meal/i.test(clean);
  const isTech = /tech|ai|phone|laptop|review|gadget/i.test(clean);
  const isVlog = /vlog|day|travel|trip|life/i.test(clean);
  const isTutorial = /how|tutorial|learn|guide/i.test(clean);

  const headlines: string[] = [];
  if (isTutorial) {
    headlines.push(`HOW TO ${upper}`, `${key} — STEP BY STEP`, `LEARN ${upper} IN 60s`);
  } else if (isGaming) {
    headlines.push(`INSANE ${key}!`, `YOU WON'T BELIEVE THIS ${key}`, `${key} GONE WRONG`);
  } else if (isFood) {
    headlines.push(`I MADE ${upper}`, `EASY ${key} RECIPE`, `${key} — THE RIGHT WAY`);
  } else if (isTech) {
    headlines.push(`${key} — HONEST REVIEW`, `IS ${key} WORTH IT?`, `${key} IN 2026`);
  } else if (isVlog) {
    headlines.push(`MY DAY ${upper}`, `A DAY WITH ${key}`, `${key} — VLOG`);
  } else {
    headlines.push(`${upper}!`, `THE TRUTH ABOUT ${key}`, `${key} — WHAT HAPPENED`);
  }

  const style = isGaming
    ? "High-energy, bold Impact font, red/black palette, heavy outline."
    : isTech
    ? "Clean, minimal, dark background with accent color for the subject."
    : isFood
    ? "Warm, appetizing tones (orange/red), close-up hero image, playful text."
    : isVlog
    ? "Bright, friendly gradient, personal photo left, big playful text right."
    : "Bold, contrasty, dark background with a single bright accent color.";

  const bg = isGaming
    ? "Dark red-to-black gradient with a slight vignette."
    : isTech
    ? "Deep navy gradient with a subtle brand-color glow."
    : isFood
    ? "Warm sunset gradient (orange → yellow)."
    : isVlog
    ? "Bright pastel gradient (peach → pink)."
    : "Purple-to-magenta gradient with a soft glow.";

  const layout = "Split the canvas roughly 60/40 — the main image or emoji on one side, and the large headline on the other. Add a small tag/label above the headline for context.";
  const textPlacement = "Place the headline in the bottom-left third for YouTube 16:9, or top-center for vertical Shorts/TikTok. Keep it inside the safe area — 8% padding from each edge.";
  const visualElements = [
    "A face or product close-up as the focal point",
    "One bright colored shape behind the headline for contrast",
    "1–2 emoji stickers for emotion (🔥 / 😱 / ✨)",
  ];

  return { headlines, layout, visualElements, background: bg, textPlacement, style };
}

interface Props {
  onApplyHeadline: (text: string) => void;
  onApplyBackground?: () => void;
}

export function AIAssistant({ onApplyHeadline }: Props) {
  const [topic, setTopic] = useState("");
  const [suggestion, setSuggestion] = useState<Suggestion | null>(null);
  const [loading, setLoading] = useState(false);

  const generate = () => {
    if (!topic.trim()) return;
    setLoading(true);
    // Simulated small delay so the UI feels intentional
    setTimeout(() => {
      setSuggestion(generateFromTopic(topic));
      setLoading(false);
    }, 350);
  };

  return (
    <div className="rounded-xl border border-[#252533] bg-[#0f0f18] p-4">
      <div className="flex items-center gap-2">
        <div className="w-7 h-7 rounded-lg brand-bg flex items-center justify-center">
          <Wand2 className="w-4 h-4 text-white" />
        </div>
        <div>
          <div className="font-semibold text-sm">AI Thumbnail Assistant</div>
          <div className="text-[11px] text-neutral-500">Get instant headline & layout ideas</div>
        </div>
      </div>

      <label className="block text-xs text-neutral-400 mt-4 mb-1.5">What is your video about?</label>
      <input
        value={topic}
        onChange={(e) => setTopic(e.target.value)}
        placeholder="e.g. Mini Chainsaw Cutting Wood"
        className="w-full bg-[#0a0a10] border border-[#262633] rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#7c5cff]"
      />

      <button
        onClick={generate}
        disabled={!topic.trim() || loading}
        className="mt-3 w-full brand-bg text-white font-semibold py-2.5 rounded-lg text-sm inline-flex items-center justify-center gap-2 disabled:opacity-60"
      >
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        Generate Thumbnail Idea
      </button>

      {suggestion && (
        <div className="mt-4 space-y-3 text-sm">
          <div>
            <div className="text-neutral-400 text-xs mb-1.5">Headline ideas</div>
            <div className="space-y-1.5">
              {suggestion.headlines.map((h, i) => (
                <button
                  key={i}
                  onClick={() => onApplyHeadline(h)}
                  className="w-full text-left px-3 py-2 rounded-lg bg-[#1a1a26] hover:bg-[#22222f] text-white text-sm border border-[#262633] transition"
                >
                  <span className="text-neutral-500 mr-2">{i + 1}.</span>{h}
                </button>
              ))}
            </div>
          </div>
          <Row label="Layout" value={suggestion.layout} />
          <Row label="Visual elements" value={suggestion.visualElements.join(" • ")} />
          <Row label="Background" value={suggestion.background} />
          <Row label="Text placement" value={suggestion.textPlacement} />
          <Row label="Overall style" value={suggestion.style} />
          <p className="text-[10px] text-neutral-600 italic pt-1">
            Tip: tap a headline to insert it into your design.
          </p>
        </div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-neutral-400 text-xs mb-0.5">{label}</div>
      <div className="text-neutral-200 leading-snug">{value}</div>
    </div>
  );
}
