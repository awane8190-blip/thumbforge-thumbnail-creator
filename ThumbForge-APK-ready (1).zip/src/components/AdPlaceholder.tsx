import { useAuth } from "../context/AuthContext";

export function AdPlaceholder({ label = "Advertisement" }: { label?: string }) {
  const { user } = useAuth();
  if (user?.plan === "premium") return null;
  return (
    <div className="w-full rounded-xl border border-dashed border-[#2a2a3a] bg-[#0f0f18] p-4 text-center text-xs text-neutral-500">
      <div className="uppercase tracking-widest text-[10px] text-neutral-600 mb-1">Ad slot</div>
      <div>{label} • Free plan supported by ads</div>
    </div>
  );
}
