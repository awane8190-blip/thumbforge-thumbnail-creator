import { forwardRef, useEffect, useRef, useState } from "react";
import type { CSSProperties } from "react";
import type { CanvasBackground, CanvasElement, ShapeElement, TextElement } from "../types";

interface Props {
  width: number;   // export width (px)
  height: number;  // export height (px)
  background: CanvasBackground;
  elements: CanvasElement[];
  selectedId?: string | null;
  onSelect?: (id: string | null) => void;
  onChange?: (id: string, patch: Partial<CanvasElement>) => void;
  onChangeCommit?: (id: string, patch: Partial<CanvasElement>) => void;
  editable?: boolean;
  className?: string;
  /** Optional fixed rendering size (used for export snapshots) */
  fixedRenderWidth?: number;
}

function bgStyle(bg: CanvasBackground): CSSProperties {
  if (bg.type === "solid") return { background: bg.color || "#111" };
  if (bg.type === "gradient" && bg.gradient) {
    return {
      background: `linear-gradient(${bg.gradient.angle}deg, ${bg.gradient.from}, ${bg.gradient.to})`,
    };
  }
  if (bg.type === "image" && bg.imageSrc) {
    return {
      backgroundImage: `url(${bg.imageSrc})`,
      backgroundSize: "cover",
      backgroundPosition: "center",
    };
  }
  return { background: "#111" };
}

function renderShape(el: ShapeElement, w: number, h: number) {
  const stroke = el.stroke && el.stroke !== "transparent" ? el.stroke : "none";
  const sw = el.strokeWidth || 0;
  const common = { fill: el.fill, stroke, strokeWidth: sw };
  if (el.shape === "rect")
    return (
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="100%" preserveAspectRatio="none">
        <rect x={sw / 2} y={sw / 2} width={w - sw} height={h - sw} rx={Math.min(w, h) * 0.04} {...common} />
      </svg>
    );
  if (el.shape === "circle")
    return (
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="100%" preserveAspectRatio="none">
        <ellipse cx={w / 2} cy={h / 2} rx={(w - sw) / 2} ry={(h - sw) / 2} {...common} />
      </svg>
    );
  if (el.shape === "triangle")
    return (
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="100%" preserveAspectRatio="none">
        <polygon points={`${w / 2},${sw} ${w - sw},${h - sw} ${sw},${h - sw}`} {...common} />
      </svg>
    );
  if (el.shape === "star")
    return (
      <svg viewBox="0 0 24 24" width="100%" height="100%" preserveAspectRatio="none">
        <polygon points="12,2 15,9 22,9 17,14 19,22 12,17 5,22 7,14 2,9 9,9" {...common} />
      </svg>
    );
  if (el.shape === "arrow")
    return (
      <svg viewBox="0 0 24 12" width="100%" height="100%" preserveAspectRatio="none">
        <polygon points="0,4 16,4 16,0 24,6 16,12 16,8 0,8" {...common} />
      </svg>
    );
  return null;
}

function TextRenderer({ el, canvasH }: { el: TextElement; canvasH: number }) {
  const fontPx = (el.fontSize / 100) * canvasH;
  const shadow = el.shadow ? `0 ${Math.max(2, fontPx * 0.06)}px ${Math.max(6, fontPx * 0.15)}px ${el.shadowColor || "#000"}` : "none";
  // Text stroke via -webkit-text-stroke provides a rasterizable outline for html-to-image.
  const strokeW = el.strokeWidth && el.strokeColor !== "transparent" ? el.strokeWidth : 0;
  const style: CSSProperties = {
    fontFamily: el.fontFamily,
    fontWeight: el.bold ? 900 : 600,
    fontStyle: el.italic ? "italic" : "normal",
    fontSize: fontPx,
    color: el.color,
    textAlign: el.align,
    textShadow: shadow,
    WebkitTextStroke: strokeW ? `${strokeW}px ${el.strokeColor}` : undefined,
    lineHeight: 1.05,
    letterSpacing: "-0.01em",
    whiteSpace: "pre-wrap",
    width: "100%",
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: el.align === "left" ? "flex-start" : el.align === "right" ? "flex-end" : "center",
    padding: 0,
    overflow: "hidden",
    wordBreak: "break-word",
  };
  return <div style={style}>{el.text}</div>;
}

export const CanvasRender = forwardRef<HTMLDivElement, Props>(function CanvasRender(
  { width, height, background, elements, selectedId, onSelect, onChange, onChangeCommit, editable, className, fixedRenderWidth },
  ref
) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [size, setSize] = useState({ w: fixedRenderWidth ?? 640, h: (fixedRenderWidth ?? 640) * (height / width) });

  useEffect(() => {
    if (fixedRenderWidth) return;
    const wrap = wrapRef.current?.parentElement;
    if (!wrap) return;
    const ro = new ResizeObserver(() => {
      const parentW = wrap.clientWidth;
      const parentH = wrap.clientHeight;
      const ratio = width / height;
      let w = parentW;
      let h = w / ratio;
      if (h > parentH) { h = parentH; w = h * ratio; }
      setSize({ w, h });
    });
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [width, height, fixedRenderWidth]);

  // Dragging logic (percent-based)
  const dragState = useRef<{ id: string; startX: number; startY: number; origX: number; origY: number } | null>(null);

  const onPointerDownEl = (e: React.PointerEvent, el: CanvasElement) => {
    if (!editable) return;
    e.stopPropagation();
    onSelect?.(el.id);
    (e.target as Element).setPointerCapture?.(e.pointerId);
    dragState.current = { id: el.id, startX: e.clientX, startY: e.clientY, origX: el.x, origY: el.y };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const d = dragState.current;
    if (!d) return;
    const dx = ((e.clientX - d.startX) / size.w) * 100;
    const dy = ((e.clientY - d.startY) / size.h) * 100;
    onChange?.(d.id, { x: clamp(d.origX + dx, 0, 100), y: clamp(d.origY + dy, 0, 100) } as any);
  };
  const onPointerUp = () => {
    const d = dragState.current;
    if (d && onChangeCommit) {
      const el = elements.find((e) => e.id === d.id);
      if (el) onChangeCommit(d.id, { x: el.x, y: el.y } as any);
    }
    dragState.current = null;
  };

  return (
    <div ref={wrapRef} className={className} style={{ position: "relative", width: size.w, height: size.h }}>
      <div
        ref={ref}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onPointerDown={() => editable && onSelect?.(null)}
        className="relative overflow-hidden rounded-lg no-select"
        style={{
          width: size.w,
          height: size.h,
          ...bgStyle(background),
          touchAction: editable ? "none" : "auto",
        }}
      >
        {elements.map((el) => {
          const left = (el.x / 100) * size.w;
          const top = (el.y / 100) * size.h;
          const w = (el.w / 100) * size.w;
          const h = (el.h / 100) * size.h;
          const isSel = editable && selectedId === el.id;
          return (
            <div
              key={el.id}
              onPointerDown={(e) => onPointerDownEl(e, el)}
              style={{
                position: "absolute",
                left,
                top,
                width: w,
                height: h,
                transform: `translate(-50%, -50%) rotate(${el.rotation}deg)`,
                transformOrigin: "center",
                opacity: el.opacity,
                outline: isSel ? "2px solid #7c5cff" : "none",
                outlineOffset: 2,
                cursor: editable ? "move" : "default",
              }}
            >
              {el.type === "text" && <TextRenderer el={el} canvasH={size.h} />}
              {el.type === "image" && (
                <img
                  src={el.src}
                  alt=""
                  draggable={false}
                  style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 4, pointerEvents: "none" }}
                />
              )}
              {el.type === "shape" && renderShape(el, w, h)}
              {el.type === "sticker" && (
                <div
                  style={{
                    fontSize: Math.min(w, h) * 0.9,
                    lineHeight: 1,
                    width: "100%",
                    height: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    pointerEvents: "none",
                  }}
                >
                  {el.emoji}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
});

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}
