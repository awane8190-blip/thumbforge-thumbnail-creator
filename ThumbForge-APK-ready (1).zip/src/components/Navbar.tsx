import { NavLink } from "react-router-dom";
import { Logo } from "./Logo";
import { useAuth } from "../context/AuthContext";
import { LogIn, User as UserIcon, Sparkles } from "lucide-react";

const links = [
  { to: "/", label: "Home", end: true },
  { to: "/templates", label: "Templates" },
  { to: "/editor", label: "Create" },
  { to: "/projects", label: "My Projects" },
  { to: "/pricing", label: "Pricing" },
  { to: "/about", label: "About" },
];

export function Navbar() {
  const { user } = useAuth();
  return (
    <header className="sticky top-0 z-40 bg-[#0a0a10]/80 backdrop-blur border-b border-[#1a1a26]">
      <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
        <Logo />
        <nav className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                `px-3 py-2 rounded-lg text-sm transition ${
                  isActive ? "text-white bg-[#1a1a26]" : "text-neutral-400 hover:text-white hover:bg-[#141420]"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          {user?.plan === "free" && (
            <NavLink
              to="/pricing"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-amber-400 to-pink-500 text-black"
            >
              <Sparkles className="w-3.5 h-3.5" /> Upgrade
            </NavLink>
          )}
          {user ? (
            <NavLink
              to="/profile"
              className="hidden md:inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#1a1a26] hover:bg-[#22222f] text-sm"
            >
              <UserIcon className="w-4 h-4" />
              <span className="max-w-[10ch] truncate">{user.name}</span>
            </NavLink>
          ) : (
            <NavLink
              to="/login"
              className="hidden md:inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#1a1a26] hover:bg-[#22222f] text-sm"
            >
              <LogIn className="w-4 h-4" /> Sign in
            </NavLink>
          )}
        </div>
      </div>
    </header>
  );
}
