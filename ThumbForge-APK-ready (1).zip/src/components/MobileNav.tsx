import { NavLink } from "react-router-dom";
import { Home, LayoutGrid, PlusSquare, Folder, User } from "lucide-react";

const items = [
  { to: "/", icon: Home, label: "Home", end: true },
  { to: "/templates", icon: LayoutGrid, label: "Templates" },
  { to: "/editor", icon: PlusSquare, label: "Create", primary: true },
  { to: "/projects", icon: Folder, label: "Projects" },
  { to: "/profile", icon: User, label: "Profile" },
];

export function MobileNav() {
  return (
    <nav
      className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-[#0a0a10]/95 backdrop-blur border-t border-[#1a1a26]"
      style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
    >
      <ul className="grid grid-cols-5">
        {items.map((it) => (
          <li key={it.to}>
            <NavLink
              to={it.to}
              end={it.end}
              className={({ isActive }) =>
                `flex flex-col items-center justify-center gap-1 py-2.5 text-[10px] font-medium ${
                  isActive ? "text-white" : "text-neutral-500"
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div
                    className={`w-11 h-8 rounded-xl flex items-center justify-center ${
                      it.primary
                        ? "brand-bg text-white shadow-lg"
                        : isActive
                        ? "bg-[#1a1a26] text-white"
                        : "text-neutral-500"
                    }`}
                  >
                    <it.icon className="w-5 h-5" />
                  </div>
                  <span>{it.label}</span>
                </>
              )}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
