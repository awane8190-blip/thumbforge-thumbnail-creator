import { Link } from "react-router-dom";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2 no-select group">
      <div className="relative w-8 h-8 rounded-lg brand-bg flex items-center justify-center shadow-lg group-active:scale-95 transition-transform">
        <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M6 3l12 6-12 6V3z" />
          <path d="M6 15l12 6" />
        </svg>
      </div>
      {!compact && (
        <div className="font-extrabold text-lg tracking-tight">
          Thumb<span className="brand-gradient">Forge</span>
        </div>
      )}
    </Link>
  );
}
