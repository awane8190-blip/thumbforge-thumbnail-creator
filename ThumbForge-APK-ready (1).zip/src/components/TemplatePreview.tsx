import { useEffect, useRef, useState } from "react";
import { CanvasRender } from "./CanvasRender";
import { FORMATS, type TemplateData } from "../types";
import type { CanvasElement } from "../types";

/**
 * Lightweight lazy-loaded template preview. It shows a gradient placeholder
 * until it becomes visible, then renders the actual mini canvas.
 */
export function TemplatePreview({ template }: { template: TemplateData }) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState(false);
  const fmt = FORMATS[template.format];
  const ratio = fmt.width / fmt.height;

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) if (e.isIntersecting) { setVisible(true); io.disconnect(); }
      },
      { rootMargin: "200px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      ref={containerRef}
      className="w-full overflow-hidden rounded-lg"
      style={{
        aspectRatio: `${ratio}`,
        background: `linear-gradient(135deg, ${template.previewGradient[0]}, ${template.previewGradient[1]})`,
      }}
    >
      {visible && (
        <CanvasRender
          width={fmt.width}
          height={fmt.height}
          background={template.data.background}
          elements={template.data.elements as CanvasElement[]}
          className="mx-auto"
        />
      )}
    </div>
  );
}
