import { Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Navbar } from "./components/Navbar";
import { MobileNav } from "./components/MobileNav";
import { AuthProvider } from "./context/AuthContext";
import { ProjectsProvider } from "./context/ProjectsContext";
import { Home } from "./pages/Home";
import { Templates } from "./pages/Templates";
import { Editor } from "./pages/Editor";
import { Projects } from "./pages/Projects";
import { Pricing } from "./pages/Pricing";
import { About } from "./pages/About";
import { AuthPage } from "./pages/Auth";
import { Profile } from "./pages/Profile";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

export default function App() {
  const location = useLocation();
  const isEditor = location.pathname.startsWith("/editor");

  return (
    <AuthProvider>
      <ProjectsProvider>
        <ScrollToTop />
        <div className={`min-h-screen flex flex-col ${!isEditor ? "pb-safe md:pb-0" : ""}`}>
          <Navbar />
          <div className="flex-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/templates" element={<Templates />} />
              <Route path="/editor" element={<Editor />} />
              <Route path="/projects" element={<Projects />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/about" element={<About />} />
              <Route path="/login" element={<AuthPage mode="login" />} />
              <Route path="/signup" element={<AuthPage mode="signup" />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="*" element={<Home />} />
            </Routes>
          </div>
          {!isEditor && (
            <footer className="border-t border-[#1a1a26] py-6 text-center text-xs text-neutral-500">
              <div className="max-w-7xl mx-auto px-4">
                © {new Date().getFullYear()} ThumbForge · Create scroll-stopping thumbnails in seconds.
              </div>
            </footer>
          )}
          {!isEditor && <MobileNav />}
        </div>
      </ProjectsProvider>
    </AuthProvider>
  );
}
