import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import type { User } from "../types";

interface AuthContextValue {
  user: User | null;
  signup: (email: string, name: string, password: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  upgrade: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);
const USER_KEY = "thumbforge.user";
const USERS_KEY = "thumbforge.users";

interface StoredUser extends User {
  passwordHash: string;
}

function simpleHash(s: string) {
  // NOT cryptographically secure. This is a demo-only local hash.
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i), (h |= 0);
  return String(h);
}

function loadUsers(): StoredUser[] {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
  } catch {
    return [];
  }
}
function saveUsers(users: StoredUser[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem(USER_KEY);
    if (raw) {
      try { setUser(JSON.parse(raw)); } catch { /* ignore */ }
    }
  }, []);

  const persist = (u: User | null) => {
    setUser(u);
    if (u) localStorage.setItem(USER_KEY, JSON.stringify(u));
    else localStorage.removeItem(USER_KEY);
  };

  const signup = async (email: string, name: string, password: string) => {
    if (!email || !password || !name) throw new Error("All fields are required");
    if (password.length < 6) throw new Error("Password must be at least 6 characters");
    const users = loadUsers();
    if (users.find((u) => u.email.toLowerCase() === email.toLowerCase())) {
      throw new Error("An account with this email already exists");
    }
    const newUser: StoredUser = {
      email, name, plan: "free", passwordHash: simpleHash(password),
    };
    users.push(newUser);
    saveUsers(users);
    const { passwordHash, ...pub } = newUser;
    void passwordHash;
    persist(pub);
  };

  const login = async (email: string, password: string) => {
    const users = loadUsers();
    const found = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!found || found.passwordHash !== simpleHash(password)) {
      throw new Error("Invalid email or password");
    }
    const { passwordHash, ...pub } = found;
    void passwordHash;
    persist(pub);
  };

  const logout = () => persist(null);

  const upgrade = () => {
    if (!user) return;
    const updated: User = { ...user, plan: "premium" };
    // Also update stored users
    const users = loadUsers();
    const idx = users.findIndex((u) => u.email === user.email);
    if (idx >= 0) { users[idx].plan = "premium"; saveUsers(users); }
    persist(updated);
  };

  return (
    <AuthContext.Provider value={{ user, signup, login, logout, upgrade }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
