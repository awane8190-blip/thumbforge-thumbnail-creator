import { createContext, useCallback, useContext, useEffect, useState, ReactNode } from "react";
import type { ProjectData } from "../types";
import { useAuth } from "./AuthContext";

interface ProjectsContextValue {
  projects: ProjectData[];
  saveProject: (p: ProjectData) => void;
  deleteProject: (id: string) => void;
  renameProject: (id: string, name: string) => void;
  duplicateProject: (id: string) => ProjectData | null;
  getProject: (id: string) => ProjectData | undefined;
}

const ProjectsContext = createContext<ProjectsContextValue | null>(null);
const KEY = "thumbforge.projects";

function loadAll(): ProjectData[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}
function saveAll(p: ProjectData[]) {
  localStorage.setItem(KEY, JSON.stringify(p));
}

export function ProjectsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [all, setAll] = useState<ProjectData[]>([]);

  useEffect(() => { setAll(loadAll()); }, []);

  // Only expose the current user's projects (or anonymous ones)
  const projects = all.filter((p) =>
    user ? p.ownerEmail === user.email : !p.ownerEmail
  );

  const persist = useCallback((next: ProjectData[]) => {
    setAll(next);
    saveAll(next);
  }, []);

  const saveProject = (p: ProjectData) => {
    const next = [...all];
    const idx = next.findIndex((x) => x.id === p.id);
    const withOwner: ProjectData = { ...p, ownerEmail: user?.email ?? null, updatedAt: Date.now() };
    if (idx >= 0) next[idx] = withOwner;
    else next.push(withOwner);
    persist(next);
  };

  const deleteProject = (id: string) => {
    persist(all.filter((x) => x.id !== id));
  };

  const renameProject = (id: string, name: string) => {
    persist(all.map((x) => (x.id === id ? { ...x, name, updatedAt: Date.now() } : x)));
  };

  const duplicateProject = (id: string): ProjectData | null => {
    const src = all.find((x) => x.id === id);
    if (!src) return null;
    const copy: ProjectData = {
      ...src,
      id: crypto.randomUUID(),
      name: src.name + " (copy)",
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    persist([...all, copy]);
    return copy;
  };

  const getProject = (id: string) => all.find((x) => x.id === id);

  return (
    <ProjectsContext.Provider value={{ projects, saveProject, deleteProject, renameProject, duplicateProject, getProject }}>
      {children}
    </ProjectsContext.Provider>
  );
}

export function useProjects() {
  const ctx = useContext(ProjectsContext);
  if (!ctx) throw new Error("useProjects must be used inside ProjectsProvider");
  return ctx;
}
