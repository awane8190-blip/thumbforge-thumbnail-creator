import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { useProjects } from "../context/ProjectsContext";
import { useAuth } from "../context/AuthContext";
import { FORMATS } from "../types";
import { Copy, Pencil, Trash2, FolderOpen, Plus } from "lucide-react";

export function Projects() {
  const { user } = useAuth();
  const { projects, deleteProject, duplicateProject, renameProject } = useProjects();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState("");

  useEffect(() => { document.title = "My Projects — ThumbForge"; }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 md:py-10">
      <div className="flex items-center justify-between mb-6 gap-2">
        <div>
          <h1 className="text-2xl md:text-4xl font-black tracking-tight">My Projects</h1>
          <p className="text-neutral-400 mt-1 text-sm">
            {user ? "Your saved thumbnails, ready when you are." : "Local projects (sign in to keep them safe on your account)."}
          </p>
        </div>
        <Link
          to="/editor"
          className="brand-bg text-white font-semibold px-3.5 py-2.5 rounded-xl inline-flex items-center gap-1.5 active:scale-95 transition"
        >
          <Plus className="w-4 h-4" /> New
        </Link>
      </div>

      {projects.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-[#262633] p-10 text-center">
          <FolderOpen className="w-10 h-10 mx-auto text-neutral-600" />
          <h2 className="mt-3 font-semibold">No projects yet</h2>
          <p className="text-neutral-400 text-sm mt-1 mb-5">Create your first thumbnail to see it here.</p>
          <Link to="/editor" className="brand-bg text-white font-semibold px-5 py-2.5 rounded-xl inline-flex items-center gap-2">
            <Plus className="w-4 h-4" /> Create thumbnail
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...projects].sort((a,b) => b.updatedAt - a.updatedAt).map((p) => {
            const fmt = FORMATS[p.format];
            const ratio = fmt.width / fmt.height;
            return (
              <div key={p.id} className="rounded-2xl bg-[#12121b] border border-[#1e1e2b] overflow-hidden">
                <Link to={`/editor?project=${p.id}`} className="block">
                  <div className="checker" style={{ aspectRatio: `${ratio}` }}>
                    {p.thumbnail ? (
                      <img src={p.thumbnail} alt={p.name} loading="lazy" className="w-full h-full object-contain" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-neutral-600 text-xs">
                        {fmt.short}
                      </div>
                    )}
                  </div>
                </Link>
                <div className="p-3">
                  {editingId === p.id ? (
                    <input
                      autoFocus
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      onBlur={() => { if (name.trim()) renameProject(p.id, name.trim()); setEditingId(null); }}
                      onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
                      className="w-full bg-[#0f0f18] border border-[#262633] rounded-lg px-2 py-1 text-sm"
                    />
                  ) : (
                    <div className="font-semibold truncate">{p.name}</div>
                  )}
                  <div className="text-xs text-neutral-500 flex items-center justify-between mt-1">
                    <span>{fmt.label}</span>
                    <span>{new Date(p.updatedAt).toLocaleDateString()}</span>
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <Link
                      to={`/editor?project=${p.id}`}
                      className="flex-1 bg-[#1a1a26] hover:bg-[#22222f] rounded-lg text-sm font-semibold px-3 py-2 text-center transition"
                    >
                      Open
                    </Link>
                    <button
                      onClick={() => { setEditingId(p.id); setName(p.name); }}
                      className="p-2 rounded-lg bg-[#1a1a26] hover:bg-[#22222f]"
                      aria-label="Rename"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => duplicateProject(p.id)}
                      className="p-2 rounded-lg bg-[#1a1a26] hover:bg-[#22222f]"
                      aria-label="Duplicate"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Delete "${p.name}"?`)) deleteProject(p.id);
                      }}
                      className="p-2 rounded-lg bg-[#1a1a26] hover:bg-red-500/20 hover:text-red-400"
                      aria-label="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
