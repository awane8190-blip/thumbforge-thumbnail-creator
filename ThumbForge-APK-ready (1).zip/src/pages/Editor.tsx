import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import {
  Type, Image as ImageIcon, Shapes, Smile, Layers, Palette,
  Undo2, Redo2, RotateCcw, Save, Download, Trash2, Copy, ChevronUp, ChevronDown,
  Bold, Italic, AlignLeft, AlignCenter, AlignRight, Wand2, X,
} from "lucide-react";
import { CanvasRender } from "../components/CanvasRender";
import { AIAssistant } from "../components/editor/AIAssistant";
import { ExportModal } from "../components/editor/ExportModal";
import { AdPlaceholder } from "../components/AdPlaceholder";
import type {
  CanvasBackground, CanvasElement, CanvasFormat, ImageElement, ProjectData, ShapeElement, StickerElement, TextElement,
} from "../types";
import { FORMATS } from "../types";
import { TEMPLATES } from "../data/templates";
import { useProjects } from "../context/ProjectsContext";
import { useAuth } from "../context/AuthContext";

type PanelId = "text" | "image" | "shapes" | "stickers" | "bg" | "layers" | "ai" | null;

interface EditorState {
  format: CanvasFormat;
  background: CanvasBackground;
  elements: CanvasElement[];
  name: string;
  id: string;
}

const DEFAULT_TEXT: Omit<TextElement, "id"> = {
  type: "text",
  x: 50, y: 50, w: 80, h: 20, rotation: 0, opacity: 1,
  text: "Your Bold Title",
  fontFamily: "Impact, sans-serif",
  fontSize: 14,
  bold: true,
  italic: false,
  align: "center",
  color: "#ffffff",
  strokeColor: "#000000",
  strokeWidth: 3,
  shadow: true,
  shadowColor: "#000000",
};

const FONT_OPTIONS = [
  { label: "Impact", value: "Impact, sans-serif" },
  { label: "Inter", value: "Inter, sans-serif" },
  { label: "Arial Black", value: "'Arial Black', sans-serif" },
  { label: "Georgia", value: "Georgia, serif" },
  { label: "Courier", value: "'Courier New', monospace" },
  { label: "Verdana", value: "Verdana, sans-serif" },
];

const PRESET_COLORS = [
  "#ffffff", "#000000", "#7c5cff", "#ff4d8f", "#22e6c1", "#ffcc00", "#ff4b4b", "#00c9ff", "#00ff88", "#ff8a00",
];

const PRESET_GRADIENTS: [string, string][] = [
  ["#7c5cff", "#ff4d8f"],
  ["#141e30", "#7c5cff"],
  ["#ff416c", "#ff4b2b"],
  ["#00c9ff", "#92fe9d"],
  ["#000000", "#ff0050"],
  ["#0f2027", "#2c5364"],
  ["#43cea2", "#185a9d"],
  ["#ffb75e", "#ed8f03"],
  ["#8e0e00", "#1f1c18"],
];

const EMOJIS = ["🔥","😱","💥","✨","⚡","💯","🚀","😂","😍","😎","🤯","👀","🎯","🏆","💰","🎮","🎵","💡","🧠","👑","💀","🤖","📱","💻","📸","🎬","🍕","☕","🌍","❤️"];

function newId() { return crypto.randomUUID(); }

function initialState(format: CanvasFormat): EditorState {
  return {
    format,
    background: { type: "gradient", gradient: { from: "#141e30", to: "#7c5cff", angle: 135 } },
    elements: [{ ...DEFAULT_TEXT, id: newId(), text: "Your Bold Title" } as TextElement],
    name: "Untitled thumbnail",
    id: newId(),
  };
}

export function Editor() {
  const [params] = useSearchParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const { saveProject, getProject } = useProjects();

  const initialFormat = (params.get("format") as CanvasFormat) || "youtube";
  const templateId = params.get("template");
  const projectId = params.get("project");

  const [state, setState] = useState<EditorState>(() => initialState(initialFormat));
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [panel, setPanel] = useState<PanelId>(null);
  const [showExport, setShowExport] = useState(false);
  const [savedToast, setSavedToast] = useState(false);

  // Undo / redo stacks
  const past = useRef<EditorState[]>([]);
  const future = useRef<EditorState[]>([]);

  const commit = useCallback((updater: (s: EditorState) => EditorState) => {
    setState((prev) => {
      past.current.push(prev);
      if (past.current.length > 60) past.current.shift();
      future.current = [];
      return updater(prev);
    });
  }, []);

  const undo = () => {
    const prev = past.current.pop();
    if (!prev) return;
    setState((cur) => { future.current.push(cur); return prev; });
  };
  const redo = () => {
    const nxt = future.current.pop();
    if (!nxt) return;
    setState((cur) => { past.current.push(cur); return nxt; });
  };
  const resetCanvas = () => {
    if (!confirm("Reset the canvas? This will remove all elements.")) return;
    commit(() => initialState(state.format));
    setSelectedId(null);
  };

  // Load template or project
  useEffect(() => {
    if (templateId) {
      const t = TEMPLATES.find((x) => x.id === templateId);
      if (t) {
        setState({
          format: t.format,
          background: JSON.parse(JSON.stringify(t.data.background)),
          elements: JSON.parse(JSON.stringify(t.data.elements)),
          name: t.name,
          id: newId(),
        });
      }
    } else if (projectId) {
      const p = getProject(projectId);
      if (p) {
        setState({
          format: p.format,
          background: p.background,
          elements: p.elements,
          name: p.name,
          id: p.id,
        });
      }
    }
     
  }, []);

  const fmt = FORMATS[state.format];

  const selected = useMemo(
    () => state.elements.find((e) => e.id === selectedId) || null,
    [state.elements, selectedId]
  );

  // Element mutation
  const patchElement = (id: string, patch: Partial<CanvasElement>) => {
    setState((prev) => ({
      ...prev,
      elements: prev.elements.map((el) => (el.id === id ? ({ ...el, ...patch } as CanvasElement) : el)),
    }));
    // Debounced undo commit — record every drag as one entry when it starts
  };
  const commitPatch = (id: string, patch: Partial<CanvasElement>) => {
    commit((s) => ({
      ...s,
      elements: s.elements.map((el) => (el.id === id ? ({ ...el, ...patch } as CanvasElement) : el)),
    }));
  };

  const addElement = (el: CanvasElement) => {
    commit((s) => ({ ...s, elements: [...s.elements, el] }));
    setSelectedId(el.id);
  };

  const deleteElement = (id: string) => {
    commit((s) => ({ ...s, elements: s.elements.filter((e) => e.id !== id) }));
    setSelectedId(null);
  };
  const duplicateElement = (id: string) => {
    const el = state.elements.find((e) => e.id === id);
    if (!el) return;
    const copy = { ...el, id: newId(), x: Math.min(100, el.x + 5), y: Math.min(100, el.y + 5) } as CanvasElement;
    commit((s) => ({ ...s, elements: [...s.elements, copy] }));
    setSelectedId(copy.id);
  };
  const moveLayer = (id: string, dir: -1 | 1) => {
    commit((s) => {
      const arr = [...s.elements];
      const i = arr.findIndex((e) => e.id === id);
      if (i < 0) return s;
      const j = i + dir;
      if (j < 0 || j >= arr.length) return s;
      [arr[i], arr[j]] = [arr[j], arr[i]];
      return { ...s, elements: arr };
    });
  };

  // Add helpers
  const addText = (text = "New Text") => {
    addElement({ ...DEFAULT_TEXT, id: newId(), text } as TextElement);
    setPanel("text");
  };
  const addShape = (shape: ShapeElement["shape"]) => {
    addElement({
      id: newId(), type: "shape", shape,
      x: 50, y: 50, w: 30, h: 30, rotation: 0, opacity: 1,
      fill: "#7c5cff", stroke: "transparent", strokeWidth: 0,
    });
  };
  const addSticker = (emoji: string) => {
    addElement({ id: newId(), type: "sticker", emoji, x: 50, y: 50, w: 18, h: 18, rotation: 0, opacity: 1 } as StickerElement);
  };

  // Image upload
  const fileRef = useRef<HTMLInputElement | null>(null);
  const bgFileRef = useRef<HTMLInputElement | null>(null);

  const handleImageUpload = (target: "element" | "bg") => (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const okTypes = ["image/png", "image/jpeg", "image/webp", "image/gif"];
    if (!okTypes.includes(file.type)) { alert("Please upload a PNG, JPG, WEBP or GIF image."); return; }
    if (file.size > 8 * 1024 * 1024) { alert("Image is larger than 8MB. Please choose a smaller image."); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const src = String(reader.result);
      if (target === "bg") {
        commit((s) => ({ ...s, background: { type: "image", imageSrc: src } }));
      } else {
        // Get natural dimensions to preserve aspect ratio
        const img = new Image();
        img.onload = () => {
          const ratio = img.width / img.height;
          const canvasRatio = fmt.width / fmt.height;
          const w = 50;
          const h = (w * canvasRatio) / ratio;
          addElement({ id: newId(), type: "image", src, x: 50, y: 50, w, h, rotation: 0, opacity: 1 } as ImageElement);
        };
        img.src = src;
      }
    };
    reader.readAsDataURL(file);
  };

  // Format switch
  const changeFormat = (f: CanvasFormat) => {
    if (f === state.format) return;
    commit((s) => ({ ...s, format: f }));
  };

  // Save
  const doSave = async () => {
    const project: ProjectData = {
      id: state.id,
      name: state.name,
      format: state.format,
      background: state.background,
      elements: state.elements,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      ownerEmail: user?.email ?? null,
    };
    saveProject(project);
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 1600);
  };

  useEffect(() => { document.title = `${state.name} — ThumbForge Editor`; }, [state.name]);

  const applyHeadline = (text: string) => {
    if (selected && selected.type === "text") {
      commitPatch(selected.id, { text } as Partial<TextElement>);
    } else {
      addElement({ ...DEFAULT_TEXT, id: newId(), text } as TextElement);
    }
  };

  return (
    <div className="flex flex-col md:flex-row h-[calc(100vh-56px)]">
      {/* Left sidebar (desktop) */}
      <aside className="hidden md:flex flex-col w-16 bg-[#0d0d15] border-r border-[#1a1a26]">
        <SidebarButton label="Text" icon={Type} active={panel==="text"} onClick={() => setPanel(panel==="text"?null:"text")} />
        <SidebarButton label="Image" icon={ImageIcon} active={panel==="image"} onClick={() => setPanel(panel==="image"?null:"image")} />
        <SidebarButton label="Shapes" icon={Shapes} active={panel==="shapes"} onClick={() => setPanel(panel==="shapes"?null:"shapes")} />
        <SidebarButton label="Stickers" icon={Smile} active={panel==="stickers"} onClick={() => setPanel(panel==="stickers"?null:"stickers")} />
        <SidebarButton label="Background" icon={Palette} active={panel==="bg"} onClick={() => setPanel(panel==="bg"?null:"bg")} />
        <SidebarButton label="Layers" icon={Layers} active={panel==="layers"} onClick={() => setPanel(panel==="layers"?null:"layers")} />
        <SidebarButton label="AI" icon={Wand2} active={panel==="ai"} onClick={() => setPanel(panel==="ai"?null:"ai")} highlight />
      </aside>

      {/* Panel content */}
      {panel && (
        <aside className="hidden md:block w-72 bg-[#0f0f18] border-r border-[#1a1a26] overflow-y-auto">
          <PanelBody
            panel={panel}
            onClose={() => setPanel(null)}
            onAddText={addText}
            onAddShape={addShape}
            onAddSticker={addSticker}
            openFile={() => fileRef.current?.click()}
            openBgFile={() => bgFileRef.current?.click()}
            state={state}
            setState={setState}
            commit={commit}
            selected={selected}
            patchElement={patchElement}
            commitPatch={commitPatch}
            elements={state.elements}
            setSelectedId={setSelectedId}
            moveLayer={moveLayer}
            deleteElement={deleteElement}
            duplicateElement={duplicateElement}
            applyHeadline={applyHeadline}
          />
        </aside>
      )}

      {/* Main canvas area */}
      <main className="flex-1 flex flex-col min-w-0 bg-[#0a0a10]">
        {/* Top bar */}
        <div className="flex items-center gap-2 px-3 py-2 border-b border-[#1a1a26]">
          <input
            value={state.name}
            onChange={(e) => setState((s) => ({ ...s, name: e.target.value }))}
            className="bg-transparent text-sm font-semibold w-40 sm:w-64 outline-none focus:bg-[#12121b] rounded px-2 py-1"
          />
          <div className="hidden sm:flex items-center gap-1 ml-2">
            {(Object.keys(FORMATS) as CanvasFormat[]).map((k) => (
              <button
                key={k}
                onClick={() => changeFormat(k)}
                className={`text-xs px-2.5 py-1 rounded-md ${state.format === k ? "bg-white text-black" : "bg-[#141420] text-neutral-400 hover:text-white"}`}
              >
                {FORMATS[k].label.split(" ")[0]}
              </button>
            ))}
          </div>
          <div className="flex-1" />
          <button onClick={undo} disabled={past.current.length === 0} className="p-2 rounded-lg hover:bg-[#1a1a26] disabled:opacity-40" aria-label="Undo">
            <Undo2 className="w-4 h-4" />
          </button>
          <button onClick={redo} disabled={future.current.length === 0} className="p-2 rounded-lg hover:bg-[#1a1a26] disabled:opacity-40" aria-label="Redo">
            <Redo2 className="w-4 h-4" />
          </button>
          <button onClick={resetCanvas} className="p-2 rounded-lg hover:bg-[#1a1a26]" aria-label="Reset">
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={doSave}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#1a1a26] hover:bg-[#22222f] text-sm"
          >
            <Save className="w-4 h-4" /> Save
          </button>
          <button
            onClick={() => setShowExport(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg brand-bg text-white font-semibold text-sm btn-glow"
          >
            <Download className="w-4 h-4" /> Export
          </button>
        </div>

        {/* Mobile format switcher */}
        <div className="sm:hidden flex items-center gap-1 overflow-x-auto px-3 py-2 border-b border-[#1a1a26]">
          {(Object.keys(FORMATS) as CanvasFormat[]).map((k) => (
            <button
              key={k}
              onClick={() => changeFormat(k)}
              className={`shrink-0 text-xs px-3 py-1.5 rounded-md ${state.format === k ? "bg-white text-black" : "bg-[#141420] text-neutral-400"}`}
            >
              {FORMATS[k].label}
            </button>
          ))}
        </div>

        {/* Canvas */}
        <div className="flex-1 min-h-0 flex items-center justify-center p-3 md:p-6 relative overflow-hidden">
          <div className="w-full h-full max-w-full max-h-full flex items-center justify-center checker rounded-2xl border border-[#1a1a26] p-3">
            <CanvasRender
              width={fmt.width}
              height={fmt.height}
              background={state.background}
              elements={state.elements}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onChange={patchElement}
              onChangeCommit={commitPatch}
              editable
            />
          </div>
        </div>

        {/* Selected element quick toolbar (both desktop & mobile) */}
        {selected && (
          <QuickToolbar
            el={selected}
            onPatch={(p) => patchElement(selected.id, p)}
            onCommit={(p) => commitPatch(selected.id, p)}
            onDuplicate={() => duplicateElement(selected.id)}
            onDelete={() => deleteElement(selected.id)}
            onLayer={(d) => moveLayer(selected.id, d)}
          />
        )}

        {/* Mobile bottom toolbar */}
        <div className="md:hidden flex items-stretch gap-1 border-t border-[#1a1a26] bg-[#0d0d15] pb-safe overflow-x-auto">
          <MobileTool icon={Type} label="Text" onClick={() => setPanel("text")} active={panel==="text"} />
          <MobileTool icon={ImageIcon} label="Image" onClick={() => setPanel("image")} active={panel==="image"} />
          <MobileTool icon={Shapes} label="Shapes" onClick={() => setPanel("shapes")} active={panel==="shapes"} />
          <MobileTool icon={Smile} label="Stickers" onClick={() => setPanel("stickers")} active={panel==="stickers"} />
          <MobileTool icon={Palette} label="BG" onClick={() => setPanel("bg")} active={panel==="bg"} />
          <MobileTool icon={Layers} label="Layers" onClick={() => setPanel("layers")} active={panel==="layers"} />
          <MobileTool icon={Wand2} label="AI" onClick={() => setPanel("ai")} active={panel==="ai"} highlight />
          <MobileTool icon={Save} label="Save" onClick={doSave} />
        </div>

        {/* Mobile panel sheet */}
        {panel && (
          <div className="md:hidden fixed inset-0 z-40 bg-black/60 flex items-end" onClick={() => setPanel(null)}>
            <div
              className="w-full bg-[#0f0f18] rounded-t-2xl border-t border-[#1a1a26] max-h-[75vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <PanelBody
                panel={panel}
                onClose={() => setPanel(null)}
                onAddText={(t) => { addText(t); setPanel(null); }}
                onAddShape={(s) => { addShape(s); setPanel(null); }}
                onAddSticker={(e) => { addSticker(e); setPanel(null); }}
                openFile={() => fileRef.current?.click()}
                openBgFile={() => bgFileRef.current?.click()}
                state={state}
                setState={setState}
                commit={commit}
                selected={selected}
                patchElement={patchElement}
                commitPatch={commitPatch}
                elements={state.elements}
                setSelectedId={setSelectedId}
                moveLayer={moveLayer}
                deleteElement={deleteElement}
                duplicateElement={duplicateElement}
                applyHeadline={applyHeadline}
              />
            </div>
          </div>
        )}

        {/* Hidden file inputs */}
        <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden onChange={handleImageUpload("element")} />
        <input ref={bgFileRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden onChange={handleImageUpload("bg")} />
      </main>

      {/* Right AI/ad column (desktop only) */}
      <aside className="hidden xl:flex flex-col w-80 border-l border-[#1a1a26] bg-[#0d0d15] p-4 gap-4 overflow-y-auto">
        <AIAssistant onApplyHeadline={applyHeadline} />
        <AdPlaceholder label="Sidebar ad slot" />
      </aside>

      {showExport && (
        <ExportModal
          width={fmt.width}
          height={fmt.height}
          background={state.background}
          elements={state.elements}
          filename={state.name}
          onClose={() => setShowExport(false)}
        />
      )}

      {savedToast && (
        <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 bg-emerald-500 text-black font-semibold text-sm px-4 py-2 rounded-full shadow-lg fade-in-up">
          Saved ✓
        </div>
      )}

      {/* Back nav for template loaded */}
      {templateId && (
        <div className="hidden">{/* placeholder to satisfy nav ref */}{String(nav)}</div>
      )}
    </div>
  );
}

/* ---------- Sidebar / Panel Components ---------- */

function SidebarButton({ label, icon: Icon, active, onClick, highlight }: {
  label: string; icon: any; active?: boolean; onClick: () => void; highlight?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 py-3 text-[10px] transition ${
        active ? "text-white bg-[#12121b]" : "text-neutral-400 hover:text-white"
      }`}
    >
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
        highlight ? "brand-bg text-white" : active ? "bg-[#1a1a26]" : ""
      }`}>
        <Icon className="w-4.5 h-4.5" />
      </div>
      {label}
    </button>
  );
}

function MobileTool({ icon: Icon, label, onClick, active, highlight }: {
  icon: any; label: string; onClick: () => void; active?: boolean; highlight?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 flex flex-col items-center gap-0.5 px-3 py-2 min-w-[64px] text-[10px] ${
        active ? "text-white" : "text-neutral-400"
      }`}
    >
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
        highlight ? "brand-bg text-white" : active ? "bg-[#1a1a26]" : ""
      }`}>
        <Icon className="w-4.5 h-4.5" />
      </div>
      {label}
    </button>
  );
}

/* ---------- Panel body ---------- */

interface PanelBodyProps {
  panel: Exclude<PanelId, null>;
  onClose: () => void;
  onAddText: (t?: string) => void;
  onAddShape: (s: ShapeElement["shape"]) => void;
  onAddSticker: (e: string) => void;
  openFile: () => void;
  openBgFile: () => void;
  state: EditorState;
  setState: React.Dispatch<React.SetStateAction<EditorState>>;
  commit: (u: (s: EditorState) => EditorState) => void;
  selected: CanvasElement | null;
  patchElement: (id: string, p: Partial<CanvasElement>) => void;
  commitPatch: (id: string, p: Partial<CanvasElement>) => void;
  elements: CanvasElement[];
  setSelectedId: (id: string | null) => void;
  moveLayer: (id: string, dir: -1 | 1) => void;
  deleteElement: (id: string) => void;
  duplicateElement: (id: string) => void;
  applyHeadline: (t: string) => void;
}

function PanelBody(props: PanelBodyProps) {
  const { panel, onClose } = props;
  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="font-bold capitalize">{panel === "bg" ? "Background" : panel === "ai" ? "AI Assistant" : panel}</div>
        <button onClick={onClose} className="p-1.5 rounded hover:bg-[#1a1a26]"><X className="w-4 h-4" /></button>
      </div>
      {panel === "text" && <TextPanel {...props} />}
      {panel === "image" && <ImagePanel {...props} />}
      {panel === "shapes" && <ShapesPanel onAdd={props.onAddShape} />}
      {panel === "stickers" && <StickersPanel onAdd={props.onAddSticker} />}
      {panel === "bg" && <BackgroundPanel {...props} />}
      {panel === "layers" && <LayersPanel {...props} />}
      {panel === "ai" && <AIAssistant onApplyHeadline={props.applyHeadline} />}
    </div>
  );
}

function TextPanel({ onAddText, selected, patchElement, commitPatch }: PanelBodyProps) {
  const t = selected?.type === "text" ? (selected as TextElement) : null;
  return (
    <div className="space-y-3">
      <button onClick={() => onAddText()} className="w-full brand-bg text-white font-semibold py-2.5 rounded-lg">+ Add text</button>
      <div className="grid grid-cols-2 gap-2">
        <button onClick={() => onAddText("BIG BOLD TITLE")} className="px-3 py-3 rounded-lg bg-[#1a1a26] text-white font-extrabold text-sm text-left">BIG TITLE</button>
        <button onClick={() => onAddText("Subtitle text")} className="px-3 py-3 rounded-lg bg-[#1a1a26] text-neutral-300 text-sm text-left">Subtitle</button>
      </div>

      {t && (
        <div className="pt-3 border-t border-[#1e1e2b] space-y-3">
          <div className="text-xs text-neutral-400">Edit selected text</div>
          <textarea
            value={t.text}
            onChange={(e) => patchElement(t.id, { text: e.target.value } as any)}
            onBlur={(e) => commitPatch(t.id, { text: e.target.value } as any)}
            rows={2}
            className="w-full bg-[#0a0a10] border border-[#262633] rounded-lg px-3 py-2 text-sm"
          />
          <div>
            <label className="text-xs text-neutral-400">Font</label>
            <select
              value={t.fontFamily}
              onChange={(e) => commitPatch(t.id, { fontFamily: e.target.value } as any)}
              className="w-full bg-[#0a0a10] border border-[#262633] rounded-lg px-3 py-2 text-sm mt-1"
            >
              {FONT_OPTIONS.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-neutral-400 flex justify-between"><span>Size</span><span>{Math.round(t.fontSize)}</span></label>
            <input
              type="range" min={4} max={40} step={0.5}
              value={t.fontSize}
              onChange={(e) => patchElement(t.id, { fontSize: parseFloat(e.target.value) } as any)}
              onMouseUp={(e) => commitPatch(t.id, { fontSize: parseFloat((e.target as HTMLInputElement).value) } as any)}
              className="w-full"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <ToggleButton active={t.bold} onClick={() => commitPatch(t.id, { bold: !t.bold } as any)}><Bold className="w-4 h-4" /></ToggleButton>
            <ToggleButton active={t.italic} onClick={() => commitPatch(t.id, { italic: !t.italic } as any)}><Italic className="w-4 h-4" /></ToggleButton>
            <div className="w-px h-6 bg-[#262633] mx-1" />
            <ToggleButton active={t.align === "left"} onClick={() => commitPatch(t.id, { align: "left" } as any)}><AlignLeft className="w-4 h-4" /></ToggleButton>
            <ToggleButton active={t.align === "center"} onClick={() => commitPatch(t.id, { align: "center" } as any)}><AlignCenter className="w-4 h-4" /></ToggleButton>
            <ToggleButton active={t.align === "right"} onClick={() => commitPatch(t.id, { align: "right" } as any)}><AlignRight className="w-4 h-4" /></ToggleButton>
          </div>

          <div>
            <div className="text-xs text-neutral-400 mb-1.5">Color</div>
            <ColorRow value={t.color} onChange={(c) => commitPatch(t.id, { color: c } as any)} />
          </div>

          <div>
            <div className="text-xs text-neutral-400 mb-1.5">Outline</div>
            <div className="flex items-center gap-2">
              <input
                type="range" min={0} max={12} step={0.5}
                value={t.strokeWidth}
                onChange={(e) => patchElement(t.id, { strokeWidth: parseFloat(e.target.value) } as any)}
                onMouseUp={(e) => commitPatch(t.id, { strokeWidth: parseFloat((e.target as HTMLInputElement).value) } as any)}
                className="flex-1"
              />
              <input
                type="color"
                value={t.strokeColor === "transparent" ? "#000000" : t.strokeColor}
                onChange={(e) => commitPatch(t.id, { strokeColor: e.target.value } as any)}
                className="w-8 h-8 rounded bg-transparent border border-[#262633] cursor-pointer"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={t.shadow} onChange={(e) => commitPatch(t.id, { shadow: e.target.checked } as any)} />
            Text shadow
          </label>
        </div>
      )}
    </div>
  );
}

function ImagePanel({ openFile }: PanelBodyProps) {
  return (
    <div className="space-y-3">
      <button onClick={openFile} className="w-full brand-bg text-white font-semibold py-3 rounded-lg">
        Upload image
      </button>
      <p className="text-xs text-neutral-500">
        Supported: PNG, JPG, WEBP, GIF · Max 8MB. Files are processed in your browser and never uploaded to a server.
      </p>
    </div>
  );
}

function ShapesPanel({ onAdd }: { onAdd: (s: ShapeElement["shape"]) => void }) {
  const shapes: ShapeElement["shape"][] = ["rect", "circle", "triangle", "arrow", "star"];
  return (
    <div className="grid grid-cols-3 gap-2">
      {shapes.map((s) => (
        <button
          key={s}
          onClick={() => onAdd(s)}
          className="aspect-square bg-[#1a1a26] hover:bg-[#22222f] rounded-lg flex items-center justify-center p-4"
        >
          <ShapeIcon shape={s} />
        </button>
      ))}
    </div>
  );
}

function ShapeIcon({ shape }: { shape: ShapeElement["shape"] }) {
  const fill = "#7c5cff";
  if (shape === "rect") return <svg viewBox="0 0 24 24" className="w-full h-full"><rect x="3" y="5" width="18" height="14" rx="2" fill={fill} /></svg>;
  if (shape === "circle") return <svg viewBox="0 0 24 24" className="w-full h-full"><circle cx="12" cy="12" r="9" fill={fill} /></svg>;
  if (shape === "triangle") return <svg viewBox="0 0 24 24" className="w-full h-full"><polygon points="12,3 22,21 2,21" fill={fill} /></svg>;
  if (shape === "arrow") return <svg viewBox="0 0 24 12" className="w-full h-full"><polygon points="0,4 16,4 16,0 24,6 16,12 16,8 0,8" fill={fill} /></svg>;
  return <svg viewBox="0 0 24 24" className="w-full h-full"><polygon points="12,2 15,9 22,9 17,14 19,22 12,17 5,22 7,14 2,9 9,9" fill={fill} /></svg>;
}

function StickersPanel({ onAdd }: { onAdd: (e: string) => void }) {
  return (
    <div className="grid grid-cols-6 gap-1.5">
      {EMOJIS.map((e) => (
        <button key={e} onClick={() => onAdd(e)} className="aspect-square bg-[#1a1a26] hover:bg-[#22222f] rounded-lg text-2xl">
          {e}
        </button>
      ))}
    </div>
  );
}

function BackgroundPanel({ state, commit, openBgFile }: PanelBodyProps) {
  return (
    <div className="space-y-4">
      <div>
        <div className="text-xs text-neutral-400 mb-1.5">Solid color</div>
        <ColorRow
          value={state.background.type === "solid" ? state.background.color || "#000" : "#000"}
          onChange={(c) => commit((s) => ({ ...s, background: { type: "solid", color: c } }))}
        />
      </div>
      <div>
        <div className="text-xs text-neutral-400 mb-1.5">Gradient presets</div>
        <div className="grid grid-cols-3 gap-2">
          {PRESET_GRADIENTS.map(([a, b], i) => (
            <button
              key={i}
              onClick={() => commit((s) => ({ ...s, background: { type: "gradient", gradient: { from: a, to: b, angle: 135 } } }))}
              className="aspect-video rounded-lg border border-[#262633]"
              style={{ background: `linear-gradient(135deg, ${a}, ${b})` }}
            />
          ))}
        </div>
      </div>
      {state.background.type === "gradient" && state.background.gradient && (
        <div>
          <div className="text-xs text-neutral-400 mb-1.5 flex justify-between">
            <span>Angle</span><span>{state.background.gradient.angle}°</span>
          </div>
          <input
            type="range" min={0} max={360}
            value={state.background.gradient.angle}
            onChange={(e) => {
              const angle = parseInt(e.target.value);
              commit((s) => s.background.type === "gradient" && s.background.gradient
                ? { ...s, background: { type: "gradient", gradient: { ...s.background.gradient, angle } } }
                : s
              );
            }}
            className="w-full"
          />
        </div>
      )}
      <div>
        <div className="text-xs text-neutral-400 mb-1.5">Custom image</div>
        <button onClick={openBgFile} className="w-full bg-[#1a1a26] hover:bg-[#22222f] py-2.5 rounded-lg text-sm">Upload background image</button>
      </div>
    </div>
  );
}

function LayersPanel({ elements, setSelectedId, moveLayer, deleteElement, duplicateElement }: PanelBodyProps) {
  return (
    <div className="space-y-1">
      {elements.length === 0 && <div className="text-xs text-neutral-500">No layers yet.</div>}
      {[...elements].reverse().map((el) => (
        <div key={el.id} className="flex items-center gap-1 bg-[#1a1a26] rounded-lg p-1.5">
          <button onClick={() => setSelectedId(el.id)} className="flex-1 text-left px-2 py-1 text-sm truncate">
            {el.type === "text" ? `📝 ${(el as TextElement).text}` :
             el.type === "image" ? "🖼️ Image" :
             el.type === "shape" ? `⬛ ${(el as ShapeElement).shape}` :
             `😀 ${(el as StickerElement).emoji}`}
          </button>
          <button onClick={() => moveLayer(el.id, 1)} className="p-1 hover:bg-[#22222f] rounded"><ChevronUp className="w-4 h-4" /></button>
          <button onClick={() => moveLayer(el.id, -1)} className="p-1 hover:bg-[#22222f] rounded"><ChevronDown className="w-4 h-4" /></button>
          <button onClick={() => duplicateElement(el.id)} className="p-1 hover:bg-[#22222f] rounded"><Copy className="w-4 h-4" /></button>
          <button onClick={() => deleteElement(el.id)} className="p-1 hover:bg-red-500/20 hover:text-red-400 rounded"><Trash2 className="w-4 h-4" /></button>
        </div>
      ))}
    </div>
  );
}

/* ---------- Quick toolbar (selected element) ---------- */

function QuickToolbar({ el, onPatch, onCommit, onDuplicate, onDelete, onLayer }: {
  el: CanvasElement;
  onPatch: (p: Partial<CanvasElement>) => void;
  onCommit: (p: Partial<CanvasElement>) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onLayer: (d: -1 | 1) => void;
}) {
  return (
    <div className="border-t border-[#1a1a26] bg-[#0d0d15] px-3 py-2 flex items-center gap-2 overflow-x-auto">
      <div className="text-xs text-neutral-500 shrink-0">Selected</div>
      <div className="flex items-center gap-1.5">
        <label className="text-[11px] text-neutral-400">Size</label>
        <input
          type="range" min={5} max={100} step={1}
          value={el.w}
          onChange={(e) => onPatch({ w: parseFloat(e.target.value), h: (el.type === "text" || el.type === "shape") ? el.h : (parseFloat(e.target.value) * el.h / el.w) } as any)}
          onMouseUp={(e) => onCommit({ w: parseFloat((e.target as HTMLInputElement).value) } as any)}
          className="w-24"
        />
      </div>
      <div className="flex items-center gap-1.5">
        <label className="text-[11px] text-neutral-400">Rotate</label>
        <input
          type="range" min={-180} max={180} step={1}
          value={el.rotation}
          onChange={(e) => onPatch({ rotation: parseFloat(e.target.value) } as any)}
          onMouseUp={(e) => onCommit({ rotation: parseFloat((e.target as HTMLInputElement).value) } as any)}
          className="w-24"
        />
      </div>
      <div className="flex items-center gap-1.5">
        <label className="text-[11px] text-neutral-400">Opacity</label>
        <input
          type="range" min={0.1} max={1} step={0.05}
          value={el.opacity}
          onChange={(e) => onPatch({ opacity: parseFloat(e.target.value) } as any)}
          onMouseUp={(e) => onCommit({ opacity: parseFloat((e.target as HTMLInputElement).value) } as any)}
          className="w-20"
        />
      </div>
      {el.type === "shape" && (
        <input
          type="color"
          value={(el as ShapeElement).fill}
          onChange={(e) => onCommit({ fill: e.target.value } as any)}
          className="w-8 h-8 rounded cursor-pointer"
        />
      )}
      <div className="flex-1" />
      <button onClick={() => onLayer(1)} className="p-2 rounded hover:bg-[#1a1a26]" aria-label="Bring forward"><ChevronUp className="w-4 h-4" /></button>
      <button onClick={() => onLayer(-1)} className="p-2 rounded hover:bg-[#1a1a26]" aria-label="Send backward"><ChevronDown className="w-4 h-4" /></button>
      <button onClick={onDuplicate} className="p-2 rounded hover:bg-[#1a1a26]" aria-label="Duplicate"><Copy className="w-4 h-4" /></button>
      <button onClick={onDelete} className="p-2 rounded hover:bg-red-500/20 hover:text-red-400" aria-label="Delete"><Trash2 className="w-4 h-4" /></button>
    </div>
  );
}

function ToggleButton({ active, onClick, children }: { active?: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`w-9 h-9 rounded-lg flex items-center justify-center border ${
        active ? "bg-white text-black border-white" : "bg-[#0a0a10] border-[#262633] text-neutral-300"
      }`}
    >
      {children}
    </button>
  );
}

function ColorRow({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      <input
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-9 h-9 rounded-lg bg-transparent border border-[#262633] cursor-pointer"
      />
      {PRESET_COLORS.map((c) => (
        <button
          key={c}
          onClick={() => onChange(c)}
          className={`w-7 h-7 rounded-lg border ${value === c ? "border-white" : "border-[#262633]"}`}
          style={{ background: c }}
          aria-label={`Color ${c}`}
        />
      ))}
    </div>
  );
}
