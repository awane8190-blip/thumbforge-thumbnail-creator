import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Check, Sparkles } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export function Pricing() {
  const { user, upgrade } = useAuth();

  useEffect(() => { document.title = "Pricing — ThumbForge"; }, []);

  const free = [
    "Create unlimited thumbnails",
    "Free templates",
    "Upload images",
    "Text, shapes, stickers, emojis",
    "Standard-quality PNG / JPG export",
    "Up to 10 saved projects",
  ];
  const pro = [
    "Everything in Free",
    "Premium template pack",
    "Extra fonts & graphics",
    "HD 2× export",
    "Advanced AI ideas",
    "Unlimited saved projects",
    "Ad-free experience",
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 md:py-14">
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs bg-[#141420] border border-[#252533] text-neutral-300 mb-4">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Choose your plan
        </div>
        <h1 className="text-3xl md:text-5xl font-black tracking-tight">Simple, honest pricing</h1>
        <p className="mt-3 text-neutral-400">Start free. Upgrade only when you need more.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Free */}
        <div className="rounded-2xl border border-[#1e1e2b] bg-[#12121b] p-6">
          <div className="flex items-baseline justify-between">
            <h2 className="text-xl font-bold">Free</h2>
            <div className="text-3xl font-black">$0</div>
          </div>
          <p className="text-neutral-400 text-sm mt-1">For creators just getting started.</p>
          <ul className="mt-5 space-y-2.5">
            {free.map((f) => (
              <li key={f} className="flex items-start gap-2 text-sm">
                <Check className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" /> {f}
              </li>
            ))}
          </ul>
          <Link
            to="/editor"
            className="mt-6 inline-flex w-full items-center justify-center bg-[#1a1a26] hover:bg-[#22222f] font-semibold px-5 py-3 rounded-xl"
          >
            Start creating
          </Link>
        </div>

        {/* Premium */}
        <div className="relative rounded-2xl p-[1px] bg-gradient-to-br from-[#7c5cff] via-[#ff4d8f] to-[#22e6c1]">
          <div className="rounded-[15px] bg-[#12121b] p-6 h-full">
            <div className="flex items-baseline justify-between">
              <h2 className="text-xl font-bold flex items-center gap-2">
                Premium <Sparkles className="w-4 h-4 text-amber-400" />
              </h2>
              <div>
                <div className="text-3xl font-black">$6<span className="text-base text-neutral-400 font-normal">/mo</span></div>
              </div>
            </div>
            <p className="text-neutral-400 text-sm mt-1">For serious creators who ship weekly.</p>
            <ul className="mt-5 space-y-2.5">
              {pro.map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" /> {f}
                </li>
              ))}
            </ul>
            {user?.plan === "premium" ? (
              <button disabled className="mt-6 inline-flex w-full items-center justify-center bg-emerald-500/20 text-emerald-300 font-semibold px-5 py-3 rounded-xl">
                You're on Premium
              </button>
            ) : (
              <button
                onClick={() => {
                  if (!user) { alert("Please sign in first to activate a plan."); return; }
                  if (confirm("Demo mode: activate Premium features on this account? No payment will be taken.")) upgrade();
                }}
                className="mt-6 inline-flex w-full items-center justify-center brand-bg text-white font-semibold px-5 py-3 rounded-xl btn-glow"
              >
                Upgrade to Premium
              </button>
            )}
            <p className="mt-3 text-[11px] text-neutral-500 text-center">
              Demo pricing — payments are not yet connected. Wire up Stripe or Paddle before going live.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
