import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export function AuthPage({ mode }: { mode: "login" | "signup" }) {
  const { login, signup } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    document.title = (mode === "login" ? "Sign in" : "Create account") + " — ThumbForge";
  }, [mode]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    setLoading(true);
    try {
      if (mode === "signup") await signup(email.trim(), name.trim(), password);
      else await login(email.trim(), password);
      nav("/projects");
    } catch (e: any) {
      setErr(e.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-10">
      <div className="rounded-2xl border border-[#1e1e2b] bg-[#12121b] p-6">
        <h1 className="text-2xl font-black tracking-tight">
          {mode === "login" ? "Sign in" : "Create your account"}
        </h1>
        <p className="text-neutral-400 text-sm mt-1">
          {mode === "login" ? "Welcome back to ThumbForge." : "Save projects to your account, forever free to start."}
        </p>

        <form onSubmit={submit} className="mt-6 space-y-3">
          {mode === "signup" && (
            <input
              type="text"
              placeholder="Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#0f0f18] border border-[#262633] rounded-xl px-4 py-3 outline-none focus:border-[#7c5cff]"
              required
            />
          )}
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-[#0f0f18] border border-[#262633] rounded-xl px-4 py-3 outline-none focus:border-[#7c5cff]"
            required
          />
          <input
            type="password"
            placeholder="Password (min 6 characters)"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-[#0f0f18] border border-[#262633] rounded-xl px-4 py-3 outline-none focus:border-[#7c5cff]"
            required
          />
          {err && <div className="text-sm text-red-400">{err}</div>}
          <button
            type="submit"
            disabled={loading}
            className="w-full brand-bg text-white font-semibold px-5 py-3 rounded-xl btn-glow disabled:opacity-60"
          >
            {loading ? "Please wait..." : mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>

        <div className="text-center text-sm text-neutral-400 mt-5">
          {mode === "login" ? (
            <>Don't have an account? <Link className="text-white underline" to="/signup">Sign up</Link></>
          ) : (
            <>Already have an account? <Link className="text-white underline" to="/login">Sign in</Link></>
          )}
        </div>

        <p className="text-[11px] text-neutral-500 text-center mt-6">
          Demo authentication stores accounts in your browser only. Connect a real backend (Supabase, Firebase, etc.) before going live.
        </p>
      </div>
    </div>
  );
}
