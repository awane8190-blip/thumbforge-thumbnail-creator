import { useEffect } from "react";
import { Link } from "react-router-dom";
import { AdPlaceholder } from "../components/AdPlaceholder";

export function About() {
  useEffect(() => { document.title = "About — ThumbForge Thumbnail Maker"; }, []);

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 md:py-14">
      <h1 className="text-3xl md:text-5xl font-black tracking-tight">About ThumbForge</h1>
      <p className="mt-4 text-neutral-300">
        ThumbForge is a lightweight thumbnail creator built for YouTube, YouTube Shorts, TikTok and Instagram
        creators. Design a cover in a few minutes — no complicated software, no learning curve.
      </p>
      <h2 className="mt-8 text-xl font-bold">Why ThumbForge?</h2>
      <ul className="mt-3 space-y-2 text-neutral-300 list-disc pl-5">
        <li>Mobile-first editor that runs smoothly on low-end Android phones.</li>
        <li>Ready-made templates for every major format.</li>
        <li>AI helper that gives you headline and layout ideas in seconds.</li>
        <li>Exports at the exact size each platform needs.</li>
      </ul>
      <h2 className="mt-8 text-xl font-bold">What ThumbForge doesn't do</h2>
      <p className="mt-2 text-neutral-400">
        We don't claim any thumbnail will "guarantee more views." Great covers help, but your content and topic
        matter most. We give you the tools — you bring the story.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Link to="/editor" className="brand-bg text-white font-semibold px-5 py-3 rounded-xl">Open the editor</Link>
        <Link to="/templates" className="bg-[#1a1a26] hover:bg-[#22222f] font-semibold px-5 py-3 rounded-xl">Browse templates</Link>
      </div>
      <div className="mt-10"><AdPlaceholder /></div>
    </div>
  );
}
