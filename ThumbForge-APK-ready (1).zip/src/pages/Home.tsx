import { Link } from "react-router-dom";
import { useEffect } from "react";
import { ArrowRight, Sparkles, Play, Smartphone, Music2, Wand2, Layers, Image as ImageIcon } from "lucide-react";
import { AdPlaceholder } from "../components/AdPlaceholder";
import { FORMATS } from "../types";

const cards = [
  { id: "youtube" as const, icon: Play, title: "YouTube Thumbnail", size: "1280 × 720", grad: "from-red-500 to-orange-500" },
  { id: "shorts" as const, icon: Smartphone, title: "YouTube Shorts", size: "1080 × 1920", grad: "from-pink-500 to-fuchsia-600" },
  { id: "tiktok" as const, icon: Music2, title: "TikTok / Instagram", size: "1080 × 1920", grad: "from-cyan-400 to-blue-600" },
];

export function Home() {
  useEffect(() => {
    document.title = "ThumbForge — Create Scroll-Stopping Thumbnails";
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden ambient">
        <div className="relative z-10 max-w-7xl mx-auto px-4 pt-10 pb-14 md:pt-20 md:pb-24 text-center">
          <div className="fade-in-up inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs bg-[#141420] border border-[#252533] text-neutral-300 mb-6">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            AI-assisted thumbnails · Free to try
          </div>
          <h1 className="fade-in-up text-4xl sm:text-5xl md:text-7xl font-black tracking-tight leading-[1.02]">
            Create <span className="brand-gradient">Scroll-Stopping</span><br className="hidden sm:block" /> Thumbnails
          </h1>
          <p className="fade-in-up mt-5 text-neutral-400 text-base md:text-lg max-w-xl mx-auto">
            Design professional thumbnails and covers without complicated software.
          </p>
          <div className="fade-in-up mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              to="/editor"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 brand-bg text-white font-semibold px-6 py-3.5 rounded-xl btn-glow active:scale-[0.98] transition"
            >
              Create Thumbnail <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/templates"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#1a1a26] hover:bg-[#22222f] text-white font-semibold px-6 py-3.5 rounded-xl border border-[#262633] transition"
            >
              Browse Templates
            </Link>
          </div>

          <div className="fade-in-up mt-10 flex items-center justify-center gap-6 text-xs text-neutral-500">
            <span>✓ No signup required</span>
            <span>✓ Free templates</span>
            <span>✓ Instant export</span>
          </div>
        </div>
      </section>

      {/* Format cards */}
      <section className="max-w-7xl mx-auto px-4 pb-8">
        <h2 className="text-xl md:text-2xl font-bold mb-4">Pick a format</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4">
          {cards.map((c) => (
            <Link
              key={c.id}
              to={`/editor?format=${c.id}`}
              className="group relative rounded-2xl p-5 bg-[#12121b] border border-[#1e1e2b] hover:border-[#2d2d40] transition overflow-hidden"
            >
              <div className={`absolute -right-8 -top-8 w-32 h-32 rounded-full bg-gradient-to-br ${c.grad} opacity-30 blur-2xl`} />
              <div className={`relative w-11 h-11 rounded-xl bg-gradient-to-br ${c.grad} flex items-center justify-center`}>
                <c.icon className="w-6 h-6 text-white" />
              </div>
              <div className="mt-4">
                <div className="font-semibold text-lg">{c.title}</div>
                <div className="text-neutral-500 text-sm">{c.size}</div>
              </div>
              <div className="mt-4 flex items-center gap-1.5 text-sm text-neutral-300 group-hover:text-white">
                Start creating <ArrowRight className="w-4 h-4 transition group-hover:translate-x-0.5" />
              </div>
              {/* Mini preview strip */}
              <div className="mt-4 rounded-lg overflow-hidden border border-[#232333]">
                <div
                  style={{
                    aspectRatio: `${FORMATS[c.id].width}/${FORMATS[c.id].height}`,
                    background: `linear-gradient(135deg, #1a1a2a, #0a0a10)`,
                  }}
                  className="w-full flex items-center justify-center text-neutral-600 text-xs"
                >
                  {FORMATS[c.id].short}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4">
          {[
            { icon: Wand2, title: "AI Idea Assistant", body: "Describe your video and get headline, layout and style suggestions in one tap." },
            { icon: Layers, title: "Powerful Editor", body: "Text, shapes, stickers, layers, undo/redo — everything you need, nothing extra." },
            { icon: ImageIcon, title: "Export in Seconds", body: "One-tap PNG or JPG export at the exact size YouTube, TikTok and Instagram require." },
          ].map((f) => (
            <div key={f.title} className="rounded-2xl p-5 bg-[#12121b] border border-[#1e1e2b]">
              <div className="w-10 h-10 rounded-lg bg-[#1a1a26] flex items-center justify-center text-brand">
                <f.icon className="w-5 h-5 text-[#7c5cff]" />
              </div>
              <div className="mt-3 font-semibold">{f.title}</div>
              <p className="text-neutral-400 text-sm mt-1">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 pb-14">
        <AdPlaceholder label="Your ad could be here — 728×90 leaderboard" />
      </section>
    </div>
  );
}
