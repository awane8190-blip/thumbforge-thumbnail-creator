import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useProjects } from "../context/ProjectsContext";
import { LogOut, Sparkles, User as UserIcon, Folder } from "lucide-react";

export function Profile() {
  const { user, logout } = useAuth();
  const { projects } = useProjects();
  const nav = useNavigate();

  useEffect(() => { document.title = "Profile — ThumbForge"; }, []);

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-10 text-center">
        <div className="rounded-2xl border border-[#1e1e2b] bg-[#12121b] p-8">
          <UserIcon className="w-10 h-10 mx-auto text-neutral-500" />
          <h1 className="mt-3 text-xl font-bold">You're not signed in</h1>
          <p className="text-neutral-400 text-sm mt-1">Sign in to save projects to your account.</p>
          <div className="mt-5 flex gap-2 justify-center">
            <Link to="/login" className="brand-bg text-white font-semibold px-5 py-3 rounded-xl">Sign in</Link>
            <Link to="/signup" className="bg-[#1a1a26] font-semibold px-5 py-3 rounded-xl">Sign up</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="rounded-2xl border border-[#1e1e2b] bg-[#12121b] p-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full brand-bg flex items-center justify-center text-lg font-bold">
            {user.name.slice(0, 1).toUpperCase()}
          </div>
          <div className="min-w-0">
            <div className="font-bold text-lg truncate">{user.name}</div>
            <div className="text-neutral-400 text-sm truncate">{user.email}</div>
          </div>
        </div>
        <div className="mt-5 flex items-center justify-between p-3 rounded-xl bg-[#0f0f18] border border-[#232333]">
          <div className="flex items-center gap-2 text-sm">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="font-semibold">Plan:</span>
            <span className="capitalize">{user.plan}</span>
          </div>
          {user.plan === "free" && (
            <Link to="/pricing" className="text-sm font-semibold bg-gradient-to-r from-amber-400 to-pink-500 text-black px-3 py-1.5 rounded-lg">
              Upgrade
            </Link>
          )}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3">
        <Link to="/projects" className="rounded-2xl border border-[#1e1e2b] bg-[#12121b] p-4 flex items-center justify-between hover:border-[#2d2d40]">
          <div className="flex items-center gap-3">
            <Folder className="w-5 h-5 text-neutral-400" />
            <div>
              <div className="font-semibold">My projects</div>
              <div className="text-xs text-neutral-500">{projects.length} project{projects.length === 1 ? "" : "s"}</div>
            </div>
          </div>
          <span className="text-sm text-neutral-400">Open →</span>
        </Link>
        <button
          onClick={() => { logout(); nav("/"); }}
          className="rounded-2xl border border-[#1e1e2b] bg-[#12121b] p-4 flex items-center gap-3 hover:border-red-500/40 hover:text-red-400 text-left"
        >
          <LogOut className="w-5 h-5" />
          <div className="font-semibold">Log out</div>
        </button>
      </div>
    </div>
  );
}
