import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { CATEGORIES, TEMPLATES } from "../data/templates";
import { TemplatePreview } from "../components/TemplatePreview";
import { AdPlaceholder } from "../components/AdPlaceholder";
import { Sparkles, Search } from "lucide-react";

export function Templates() {
  const [cat, setCat] = useState<string>("All");
  const [q, setQ] = useState("");

  useEffect(() => {
    document.title = "Templates — ThumbForge Thumbnail Maker";
  }, []);

  const filtered = useMemo(() => {
    return TEMPLATES.filter((t) => {
      const matchCat = cat === "All" || t.category === cat;
      const matchQ = !q || t.name.toLowerCase().includes(q.toLowerCase());
      return matchCat && matchQ;
    });
  }, [cat, q]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 md:py-10">
      <div className="mb-6">
        <h1 className="text-2xl md:text-4xl font-black tracking-tight">Template Library</h1>
        <p className="text-neutral-400 mt-1 text-sm md:text-base">Start from a proven design. Tap "Use Template" to open it in the editor.</p>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search templates..."
          className="w-full pl-9 pr-3 py-3 rounded-xl bg-[#12121b] border border-[#1e1e2b] focus:border-[#7c5cff] outline-none"
        />
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto pb-3 -mx-4 px-4 mb-4">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`shrink-0 px-4 py-2 rounded-full text-sm border transition ${
              cat === c
                ? "bg-white text-black border-white"
                : "bg-[#12121b] text-neutral-300 border-[#1e1e2b] hover:border-[#333]"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((t) => (
          <div key={t.id} className="group rounded-2xl bg-[#12121b] border border-[#1e1e2b] overflow-hidden hover:border-[#2d2d40] transition">
            <div className="p-3">
              <TemplatePreview template={t} />
            </div>
            <div className="px-4 pb-4 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="font-semibold truncate flex items-center gap-1.5">
                  {t.name}
                  {t.premium && (
                    <span className="inline-flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded bg-amber-400/10 text-amber-400 border border-amber-500/30">
                      <Sparkles className="w-2.5 h-2.5" /> PRO
                    </span>
                  )}
                </div>
                <div className="text-xs text-neutral-500">{t.category} · {t.format.toUpperCase()}</div>
              </div>
              <Link
                to={`/editor?template=${t.id}`}
                className="shrink-0 brand-bg text-white text-sm font-semibold px-3.5 py-2 rounded-lg active:scale-95 transition"
              >
                Use Template
              </Link>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16 text-neutral-500">No templates match your search.</div>
      )}

      <div className="mt-10">
        <AdPlaceholder />
      </div>
    </div>
  );
}
