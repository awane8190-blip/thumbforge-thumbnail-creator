import type { TemplateData } from "../types";

// Note: Template previews are rendered from `data` at runtime (no external images).
// `previewGradient` provides a fast lazy background while the mini-preview mounts.
const uid = (s: string) => s;

export const CATEGORIES = [
  "All",
  "YouTube",
  "Shorts",
  "TikTok",
  "Gaming",
  "AI",
  "News",
  "Education",
  "Vlog",
  "Technology",
] as const;

export const TEMPLATES: TemplateData[] = [
  {
    id: uid("t-yt-gaming-1"),
    name: "Epic Gaming Moment",
    category: "Gaming",
    format: "youtube",
    previewGradient: ["#ff004d", "#7c00ff"],
    data: {
      format: "youtube",
      background: { type: "gradient", gradient: { from: "#150029", to: "#ff004d", angle: 135 } },
      elements: [
        { id: "e1", type: "shape", shape: "rect", x: 0, y: 60, w: 100, h: 40, rotation: 0, opacity: 0.5, fill: "#000000", stroke: "transparent", strokeWidth: 0 },
        { id: "e2", type: "text", x: 50, y: 70, w: 92, h: 22, rotation: 0, opacity: 1, text: "INSANE WIN!", fontFamily: "Impact, sans-serif", fontSize: 18, bold: true, italic: false, align: "center", color: "#ffffff", strokeColor: "#000000", strokeWidth: 4, shadow: true, shadowColor: "#000" },
        { id: "e3", type: "sticker", emoji: "🎮", x: 15, y: 25, w: 22, h: 22, rotation: -12, opacity: 1 },
        { id: "e4", type: "sticker", emoji: "🔥", x: 82, y: 22, w: 20, h: 20, rotation: 10, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-yt-tech-1"),
    name: "Tech Review Clean",
    category: "Technology",
    format: "youtube",
    previewGradient: ["#0f2027", "#2c5364"],
    data: {
      format: "youtube",
      background: { type: "gradient", gradient: { from: "#0f2027", to: "#2c5364", angle: 120 } },
      elements: [
        { id: "e1", type: "text", x: 4, y: 20, w: 60, h: 18, rotation: 0, opacity: 1, text: "REVIEW", fontFamily: "Inter, sans-serif", fontSize: 8, bold: true, italic: false, align: "left", color: "#22e6c1", strokeColor: "transparent", strokeWidth: 0, shadow: false, shadowColor: "#000" },
        { id: "e2", type: "text", x: 4, y: 45, w: 70, h: 30, rotation: 0, opacity: 1, text: "Is it worth\nthe hype?", fontFamily: "Inter, sans-serif", fontSize: 16, bold: true, italic: false, align: "left", color: "#ffffff", strokeColor: "transparent", strokeWidth: 0, shadow: true, shadowColor: "#000" },
        { id: "e3", type: "shape", shape: "circle", x: 80, y: 50, w: 30, h: 55, rotation: 0, opacity: 0.9, fill: "#7c5cff", stroke: "transparent", strokeWidth: 0 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-yt-vlog-1"),
    name: "Daily Vlog Bright",
    category: "Vlog",
    format: "youtube",
    previewGradient: ["#ffb75e", "#ed8f03"],
    data: {
      format: "youtube",
      background: { type: "gradient", gradient: { from: "#ffb75e", to: "#ed8f03", angle: 160 } },
      elements: [
        { id: "e1", type: "text", x: 50, y: 50, w: 92, h: 40, rotation: -2, opacity: 1, text: "MY DAY IN\nTOKYO", fontFamily: "Impact, sans-serif", fontSize: 20, bold: true, italic: false, align: "center", color: "#ffffff", strokeColor: "#000000", strokeWidth: 5, shadow: true, shadowColor: "#000" },
        { id: "e2", type: "sticker", emoji: "🗼", x: 15, y: 80, w: 15, h: 15, rotation: 0, opacity: 1 },
        { id: "e3", type: "sticker", emoji: "✈️", x: 85, y: 15, w: 15, h: 15, rotation: 20, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-yt-news-1"),
    name: "Breaking News",
    category: "News",
    format: "youtube",
    previewGradient: ["#8e0e00", "#1f1c18"],
    data: {
      format: "youtube",
      background: { type: "gradient", gradient: { from: "#1f1c18", to: "#8e0e00", angle: 90 } },
      elements: [
        { id: "e1", type: "shape", shape: "rect", x: 0, y: 0, w: 40, h: 15, rotation: 0, opacity: 1, fill: "#ff2b2b", stroke: "transparent", strokeWidth: 0 },
        { id: "e2", type: "text", x: 2, y: 3, w: 40, h: 10, rotation: 0, opacity: 1, text: "BREAKING", fontFamily: "Inter, sans-serif", fontSize: 7, bold: true, italic: false, align: "left", color: "#ffffff", strokeColor: "transparent", strokeWidth: 0, shadow: false, shadowColor: "#000" },
        { id: "e3", type: "text", x: 4, y: 45, w: 92, h: 40, rotation: 0, opacity: 1, text: "HUGE STORY\nJUST DROPPED", fontFamily: "Inter, sans-serif", fontSize: 15, bold: true, italic: false, align: "left", color: "#ffffff", strokeColor: "#000000", strokeWidth: 2, shadow: true, shadowColor: "#000" },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-yt-edu-1"),
    name: "Learn Fast",
    category: "Education",
    format: "youtube",
    premium: true,
    previewGradient: ["#4facfe", "#00f2fe"],
    data: {
      format: "youtube",
      background: { type: "gradient", gradient: { from: "#4facfe", to: "#00f2fe", angle: 135 } },
      elements: [
        { id: "e1", type: "text", x: 50, y: 45, w: 90, h: 40, rotation: 0, opacity: 1, text: "LEARN\nIN 5 MIN", fontFamily: "Inter, sans-serif", fontSize: 22, bold: true, italic: false, align: "center", color: "#0a1330", strokeColor: "transparent", strokeWidth: 0, shadow: false, shadowColor: "#000" },
        { id: "e2", type: "sticker", emoji: "🧠", x: 15, y: 75, w: 18, h: 18, rotation: -10, opacity: 1 },
        { id: "e3", type: "sticker", emoji: "⚡", x: 82, y: 20, w: 16, h: 16, rotation: 15, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-yt-ai-1"),
    name: "AI Deep Dive",
    category: "AI",
    format: "youtube",
    previewGradient: ["#141e30", "#7c5cff"],
    data: {
      format: "youtube",
      background: { type: "gradient", gradient: { from: "#141e30", to: "#7c5cff", angle: 120 } },
      elements: [
        { id: "e1", type: "text", x: 4, y: 20, w: 60, h: 12, rotation: 0, opacity: 1, text: "AI • 2026", fontFamily: "Inter, sans-serif", fontSize: 7, bold: true, italic: false, align: "left", color: "#22e6c1", strokeColor: "transparent", strokeWidth: 0, shadow: false, shadowColor: "#000" },
        { id: "e2", type: "text", x: 4, y: 45, w: 70, h: 30, rotation: 0, opacity: 1, text: "The Future\nis Here.", fontFamily: "Inter, sans-serif", fontSize: 18, bold: true, italic: true, align: "left", color: "#ffffff", strokeColor: "transparent", strokeWidth: 0, shadow: true, shadowColor: "#000" },
        { id: "e3", type: "sticker", emoji: "🤖", x: 80, y: 55, w: 30, h: 40, rotation: 0, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-shorts-1"),
    name: "Shorts Hook",
    category: "Shorts",
    format: "shorts",
    previewGradient: ["#ff416c", "#ff4b2b"],
    data: {
      format: "shorts",
      background: { type: "gradient", gradient: { from: "#ff416c", to: "#ff4b2b", angle: 180 } },
      elements: [
        { id: "e1", type: "text", x: 50, y: 40, w: 92, h: 30, rotation: -3, opacity: 1, text: "YOU WON'T\nBELIEVE\nTHIS", fontFamily: "Impact, sans-serif", fontSize: 12, bold: true, italic: false, align: "center", color: "#ffffff", strokeColor: "#000000", strokeWidth: 4, shadow: true, shadowColor: "#000" },
        { id: "e2", type: "sticker", emoji: "😱", x: 50, y: 75, w: 25, h: 15, rotation: 0, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-shorts-2"),
    name: "Shorts Question",
    category: "Shorts",
    format: "shorts",
    previewGradient: ["#00c9ff", "#92fe9d"],
    data: {
      format: "shorts",
      background: { type: "gradient", gradient: { from: "#00c9ff", to: "#92fe9d", angle: 160 } },
      elements: [
        { id: "e1", type: "text", x: 50, y: 45, w: 90, h: 30, rotation: 0, opacity: 1, text: "CAN YOU\nDO THIS?", fontFamily: "Inter, sans-serif", fontSize: 14, bold: true, italic: false, align: "center", color: "#0a1330", strokeColor: "transparent", strokeWidth: 0, shadow: false, shadowColor: "#000" },
        { id: "e2", type: "sticker", emoji: "🤔", x: 50, y: 22, w: 22, h: 12, rotation: 0, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-tiktok-1"),
    name: "TikTok POV",
    category: "TikTok",
    format: "tiktok",
    previewGradient: ["#000000", "#ff0050"],
    data: {
      format: "tiktok",
      background: { type: "gradient", gradient: { from: "#000000", to: "#ff0050", angle: 180 } },
      elements: [
        { id: "e1", type: "text", x: 50, y: 20, w: 90, h: 12, rotation: 0, opacity: 1, text: "POV:", fontFamily: "Inter, sans-serif", fontSize: 8, bold: true, italic: false, align: "center", color: "#22e6c1", strokeColor: "transparent", strokeWidth: 0, shadow: false, shadowColor: "#000" },
        { id: "e2", type: "text", x: 50, y: 45, w: 90, h: 30, rotation: 0, opacity: 1, text: "you found\nthe secret\nrecipe", fontFamily: "Inter, sans-serif", fontSize: 12, bold: true, italic: true, align: "center", color: "#ffffff", strokeColor: "transparent", strokeWidth: 0, shadow: true, shadowColor: "#000" },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-tiktok-2"),
    name: "TikTok Trend",
    category: "TikTok",
    format: "tiktok",
    premium: true,
    previewGradient: ["#25aae1", "#4481eb"],
    data: {
      format: "tiktok",
      background: { type: "gradient", gradient: { from: "#25aae1", to: "#4481eb", angle: 200 } },
      elements: [
        { id: "e1", type: "text", x: 50, y: 45, w: 90, h: 30, rotation: -4, opacity: 1, text: "TRY THIS\nTREND", fontFamily: "Impact, sans-serif", fontSize: 16, bold: true, italic: false, align: "center", color: "#ffffff", strokeColor: "#0a1330", strokeWidth: 3, shadow: true, shadowColor: "#000" },
        { id: "e2", type: "sticker", emoji: "🎵", x: 20, y: 75, w: 16, h: 10, rotation: 0, opacity: 1 },
        { id: "e3", type: "sticker", emoji: "✨", x: 80, y: 22, w: 16, h: 10, rotation: 0, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-gaming-2"),
    name: "New Game Drop",
    category: "Gaming",
    format: "youtube",
    previewGradient: ["#00ff88", "#003a2f"],
    data: {
      format: "youtube",
      background: { type: "gradient", gradient: { from: "#003a2f", to: "#00ff88", angle: 45 } },
      elements: [
        { id: "e1", type: "text", x: 50, y: 45, w: 90, h: 30, rotation: 0, opacity: 1, text: "NEW GAME\nJUST DROPPED", fontFamily: "Impact, sans-serif", fontSize: 16, bold: true, italic: false, align: "center", color: "#0a1330", strokeColor: "#ffffff", strokeWidth: 3, shadow: true, shadowColor: "#000" },
        { id: "e2", type: "sticker", emoji: "🕹️", x: 15, y: 75, w: 15, h: 20, rotation: -10, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-ai-2"),
    name: "AI Tool Review",
    category: "AI",
    format: "youtube",
    previewGradient: ["#43cea2", "#185a9d"],
    data: {
      format: "youtube",
      background: { type: "gradient", gradient: { from: "#185a9d", to: "#43cea2", angle: 135 } },
      elements: [
        { id: "e1", type: "text", x: 50, y: 45, w: 90, h: 30, rotation: 0, opacity: 1, text: "5 AI TOOLS\nYOU NEED", fontFamily: "Inter, sans-serif", fontSize: 16, bold: true, italic: false, align: "center", color: "#ffffff", strokeColor: "transparent", strokeWidth: 0, shadow: true, shadowColor: "#000" },
        { id: "e2", type: "sticker", emoji: "🤖", x: 82, y: 78, w: 18, h: 18, rotation: 0, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
  {
    id: uid("t-edu-2"),
    name: "Study Tips",
    category: "Education",
    format: "youtube",
    previewGradient: ["#fceabb", "#f8b500"],
    data: {
      format: "youtube",
      background: { type: "gradient", gradient: { from: "#f8b500", to: "#fceabb", angle: 160 } },
      elements: [
        { id: "e1", type: "text", x: 50, y: 45, w: 90, h: 30, rotation: 0, opacity: 1, text: "STUDY\nSMARTER", fontFamily: "Inter, sans-serif", fontSize: 20, bold: true, italic: false, align: "center", color: "#3a1e00", strokeColor: "transparent", strokeWidth: 0, shadow: false, shadowColor: "#000" },
        { id: "e2", type: "sticker", emoji: "📚", x: 15, y: 78, w: 18, h: 18, rotation: 0, opacity: 1 },
      ],
      ownerEmail: null,
    },
  },
];
