export type CanvasFormat = "youtube" | "shorts" | "tiktok" | "instagram";

export interface FormatSpec {
  id: CanvasFormat;
  label: string;
  width: number;
  height: number;
  short: string;
}

export const FORMATS: Record<CanvasFormat, FormatSpec> = {
  youtube: { id: "youtube", label: "YouTube Thumbnail", width: 1280, height: 720, short: "1280 × 720" },
  shorts: { id: "shorts", label: "YouTube Shorts", width: 1080, height: 1920, short: "1080 × 1920" },
  tiktok: { id: "tiktok", label: "TikTok", width: 1080, height: 1920, short: "1080 × 1920" },
  instagram: { id: "instagram", label: "Instagram Story", width: 1080, height: 1920, short: "1080 × 1920" },
};

export type ElementType = "text" | "image" | "shape" | "sticker";

export interface BaseElement {
  id: string;
  type: ElementType;
  x: number; // percentage 0-100
  y: number;
  w: number; // percentage of canvas width
  h: number;
  rotation: number;
  opacity: number;
  locked?: boolean;
}

export interface TextElement extends BaseElement {
  type: "text";
  text: string;
  fontFamily: string;
  fontSize: number; // in px relative to canvas height (as percentage)
  bold: boolean;
  italic: boolean;
  align: "left" | "center" | "right";
  color: string;
  strokeColor: string;
  strokeWidth: number;
  shadow: boolean;
  shadowColor: string;
}

export interface ImageElement extends BaseElement {
  type: "image";
  src: string;
}

export interface ShapeElement extends BaseElement {
  type: "shape";
  shape: "rect" | "circle" | "triangle" | "arrow" | "star";
  fill: string;
  stroke: string;
  strokeWidth: number;
}

export interface StickerElement extends BaseElement {
  type: "sticker";
  emoji: string;
}

export type CanvasElement = TextElement | ImageElement | ShapeElement | StickerElement;

export interface CanvasBackground {
  type: "solid" | "gradient" | "image";
  color?: string;
  gradient?: { from: string; to: string; angle: number };
  imageSrc?: string;
}

export interface ProjectData {
  id: string;
  name: string;
  format: CanvasFormat;
  background: CanvasBackground;
  elements: CanvasElement[];
  createdAt: number;
  updatedAt: number;
  thumbnail?: string; // dataURL preview
  ownerEmail?: string | null;
}

export interface TemplateData {
  id: string;
  name: string;
  category: string;
  format: CanvasFormat;
  premium?: boolean;
  previewGradient: [string, string];
  data: Omit<ProjectData, "id" | "name" | "createdAt" | "updatedAt">;
}

export interface User {
  email: string;
  name: string;
  plan: "free" | "premium";
}
